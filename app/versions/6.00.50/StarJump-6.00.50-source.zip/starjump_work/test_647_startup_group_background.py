from pathlib import Path
ROOT = Path(__file__).resolve().parent
props = (ROOT / 'nb4a.properties').read_text()
config = (ROOT / 'app/src/main/java/io/nekohasekai/sagernet/ui/ConfigurationFragment.kt').read_text()
main = (ROOT / 'app/src/main/java/io/nekohasekai/sagernet/ui/MainActivity.kt').read_text()
settings = (ROOT / 'app/src/main/java/io/nekohasekai/sagernet/ui/SettingsPreferenceFragment.kt').read_text()
group_screen = (ROOT / 'app/src/main/java/io/nekohasekai/sagernet/ui/GroupFragment.kt').read_text()
workflow = (ROOT / '.github/workflows/starjump-arm64.yml').read_text()

assert 'PACKAGE_NAME=com.xingyue.app' in props
assert 'VERSION_NAME=6.00.50' in props
assert 'VERSION_CODE=72' in props
assert "versionCode='360' versionName='6.00.50'" in workflow
assert "StarJump-6.00.50-source.zip" in workflow
assert 'refreshGroupListIfVisibilityChanged' in config
assert 'override suspend fun groupUpdated(groupId: Long)' in config
assert 'SagerDatabase.proxyDao.countByGroup(groupId) > 0L' in config
assert 'applyStarJumpBackground(view)' in config
assert 'mainBackgroundUri' in main and 'BitmapFactory.decodeStream' in main
assert 'ActivityResultContracts.OpenDocument()' in settings
assert 'takePersistableUriPermission' in settings
assert 'applyStarJumpBackground' not in group_screen
print('PASS: package/version metadata and ARM64 workflow are aligned for 6.00.50')
print('PASS: main-page group adapter reconciles newly visible and newly empty groups')
print('PASS: background picker persistence and main-page application are connected')
