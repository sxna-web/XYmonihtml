from pathlib import Path
ROOT = Path(__file__).resolve().parent
proxy_group = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/database/ProxyGroup.kt").read_text()
protocols = (ROOT / "app/src/main/java/moe/matsuri/nb4a/Protocols.kt").read_text()
raw = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/RawUpdater.kt").read_text()
config = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/ui/ConfigurationFragment.kt").read_text()
props = (ROOT / "nb4a.properties").read_text()

# The Boolean Room field remains intact, while the helper method no longer
# collides with Java/Kotlin Boolean getter naming.
assert "var starJumpBuiltIn: Boolean = false" in proxy_group
assert "fun isStarJumpReservedGroup(): Boolean" in proxy_group
assert "fun isStarJumpBuiltIn(): Boolean" not in proxy_group
assert "isStarJumpBuiltIn()" not in "\n".join(p.read_text() for p in (ROOT / "app/src/main/java").rglob("*.kt"))

# Complete protocol identity ignores display names but includes serialized
# credentials, security, transport, plugin and config settings via AbstractBean.
assert "bean.hashCode()" in protocols
assert "bean == other.bean" in protocols
assert "serverAddress + bean.serverPort" not in protocols
assert "Protocols.Deduplication(_proxy)" in raw
assert "Protocols.Deduplication(pf.requireBean())" in config

# Keep ordinary primary/backup fetching and the known working built-in raw URL.
assert "listOf(subscription.link, subscription.backupLink)" in raw
assert "ReferenceSubscription.sourceUrlFor(proxyGroup)" in raw
assert "parseRaw(parseText)" in raw
assert "EightDegreeSource" not in raw
assert not (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/EightDegreeSource.kt").exists()

assert "VERSION_NAME=6.00.50" in props
assert "VERSION_CODE=72" in props
print("PASS: Room Boolean getter conflict is removed without deleting the persisted field")
print("PASS: built-in group protection now uses the renamed helper")
print("PASS: deduplication uses complete protocol identity and ignores display names")
print("PASS: primary/backup HTTP parsing and verified built-in source are retained")
print("PASS: obsolete EightDegree AES/mirror loader is removed")
print("PASS: version metadata is 6.00.50 / code 72")
