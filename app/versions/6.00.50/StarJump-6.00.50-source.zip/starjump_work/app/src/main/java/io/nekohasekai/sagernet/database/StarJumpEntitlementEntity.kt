package io.nekohasekai.sagernet.database

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

/** One independently-owned StarJump APP entitlement. Tokens are always ciphertext. */
@Entity(
    tableName = "starjump_entitlements",
    primaryKeys = ["entitlementKey"],
    indices = [Index(value = ["adminUserId"]), Index(value = ["cardId"]), Index(value = ["status"])]
)
data class StarJumpEntitlementEntity(
    val entitlementKey: String,
    val entitlementId: String?,
    val adminUserId: String,
    val cardId: String?,
    val expiresAt: String?,
    val status: String,
    val tokenCiphertext: String,
    val lastVerifiedAt: Long?,
    val createdAt: Long,
    val updatedAt: Long
)

@Dao
interface StarJumpEntitlementDao {
    @Query("SELECT * FROM starjump_entitlements ORDER BY updatedAt DESC")
    fun all(): List<StarJumpEntitlementEntity>

    @Query("SELECT * FROM starjump_entitlements WHERE entitlementKey = :key LIMIT 1")
    fun byKey(key: String): StarJumpEntitlementEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsert(entity: StarJumpEntitlementEntity)

    @Query("UPDATE starjump_entitlements SET status = :status, updatedAt = :updatedAt WHERE entitlementKey = :key")
    fun updateStatus(key: String, status: String, updatedAt: Long): Int

    @Query("DELETE FROM starjump_entitlements WHERE entitlementKey = :key")
    fun deleteByKey(key: String): Int
}
