package io.nekohasekai.sagernet.starjump

import android.content.Context
import io.nekohasekai.sagernet.database.SagerDatabase
import io.nekohasekai.sagernet.database.StarJumpEntitlementEntity
import java.security.MessageDigest

/** Persists one row per entitlement; a failed migration never removes the legacy token. */
object StarJumpEntitlementStore {
    data class DecryptedEntitlement(val record: StarJumpEntitlementEntity, val token: String)

    private fun digest(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }

    private fun dao() = SagerDatabase.instance.starJumpEntitlementDao()

    fun migrateLegacyToken(context: Context): Boolean {
        val prefs = context.getSharedPreferences("starjump", Context.MODE_PRIVATE)
        val legacyToken = prefs.getString("token", null)?.takeIf { it.isNotBlank() } ?: return true
        return try {
            val adminId = prefs.getString("admin_user_id", null)?.takeIf { it.isNotBlank() } ?: "legacy-unknown-admin"
            val expiresAt = prefs.getString("expires_at", null)
            val key = "legacy:$adminId:${digest(legacyToken)}"
            val encrypted = StarJumpTokenVault.encrypt(legacyToken)
            check(StarJumpTokenVault.decrypt(encrypted) == legacyToken) { "Legacy token encryption verification failed" }
            val now = System.currentTimeMillis()
            val row = StarJumpEntitlementEntity(
                entitlementKey = key,
                entitlementId = null,
                adminUserId = adminId,
                cardId = null,
                expiresAt = expiresAt,
                status = "active",
                tokenCiphertext = encrypted,
                lastVerifiedAt = null,
                createdAt = now,
                updatedAt = now
            )
            dao().upsert(row)
            val stored = dao().byKey(key) ?: error("Legacy entitlement read-back failed")
            check(StarJumpTokenVault.decrypt(stored.tokenCiphertext) == legacyToken) {
                "Legacy entitlement database verification failed"
            }
            // Clear plaintext only after ciphertext was durably read back and verified.
            check(prefs.edit().remove("token").remove("expires_at").remove("admin_user_id").commit()) {
                "Legacy plaintext cleanup did not commit"
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun saveRedeemed(
        context: Context,
        token: String,
        adminUserId: String?,
        entitlementId: String?,
        cardId: String?,
        expiresAt: String?
    ): Boolean {
        if (token.isBlank() || token == "null" || adminUserId.isNullOrBlank() || adminUserId == "null") return false
        return try {
            val encrypted = StarJumpTokenVault.encrypt(token)
            check(StarJumpTokenVault.decrypt(encrypted) == token) { "Token encryption verification failed" }
            val admin = adminUserId
            val key = if (!entitlementId.isNullOrBlank()) {
                "entitlement:$admin:$entitlementId"
            } else {
                "redeemed:$admin:${cardId ?: "unknown-card"}:${digest(token)}"
            }
            val now = System.currentTimeMillis()
            val row = StarJumpEntitlementEntity(
                entitlementKey = key,
                entitlementId = entitlementId,
                adminUserId = admin,
                cardId = cardId,
                expiresAt = expiresAt,
                status = "active",
                tokenCiphertext = encrypted,
                lastVerifiedAt = null,
                createdAt = now,
                updatedAt = now
            )
            dao().upsert(row)
            val stored = dao().byKey(key) ?: error("Entitlement read-back failed")
            check(StarJumpTokenVault.decrypt(stored.tokenCiphertext) == token) {
                "Entitlement database verification failed"
            }
            // Also migrate any previous single-token installation without overwriting this row.
            migrateLegacyToken(context)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun readAll(context: Context): List<DecryptedEntitlement> {
        migrateLegacyToken(context)
        return try {
            dao().all().filter { it.status == "active" }.mapNotNull { row ->
                try {
                    DecryptedEntitlement(row, StarJumpTokenVault.decrypt(row.tokenCiphertext))
                } catch (_: Exception) {
                    null
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
