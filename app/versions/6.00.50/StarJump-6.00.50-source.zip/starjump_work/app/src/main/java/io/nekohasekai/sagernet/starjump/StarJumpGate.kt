package io.nekohasekai.sagernet.starjump

import android.app.Activity
import android.content.Intent
import android.view.View
import com.google.android.material.snackbar.Snackbar
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 启动检查：未激活 / 即将到期 / 已过期。
 * 不做全屏弹窗，只弹一次引导 + 底部提示条（不打断使用）。
 */
object StarJumpGate {

    fun check(activity: Activity, root: View) {
        val prefs = activity.getSharedPreferences("starjump", Activity.MODE_PRIVATE)
        val entitlements = StarJumpEntitlementStore.readAll(activity)
        if (entitlements.isEmpty()) {
            val guided = prefs.getBoolean("guided", false)
            if (!guided) {
                prefs.edit().putBoolean("guided", true).apply()
                activity.startActivity(Intent(activity, ActivationActivity::class.java))
            } else {
                Snackbar.make(root, "尚未激活卡密", Snackbar.LENGTH_INDEFINITE)
                    .setAction("去激活") {
                        activity.startActivity(Intent(activity, ActivationActivity::class.java))
                    }
                    .show()
            }
            return
        }

        val remaining = entitlements.mapNotNull { it.record.expiresAt?.let(::daysLeft) }
        if (remaining.isEmpty()) return
        val active = remaining.filter { it >= 0 }
        if (active.isEmpty()) {
            Snackbar.make(root, "所有已保存的卡密授权均已过期，节点停止更新", Snackbar.LENGTH_INDEFINITE)
                .setAction("续费") {
                    activity.startActivity(Intent(activity, ActivationActivity::class.java))
                }
                .show()
        } else {
            val soonest = active.minOrNull() ?: return
            if (soonest <= 3) {
                Snackbar.make(root, "有授权还有 $soonest 天到期；其他管理员的有效授权不受影响", Snackbar.LENGTH_LONG)
                    .setAction("查看") {
                        activity.startActivity(Intent(activity, ActivationActivity::class.java))
                    }
                    .show()
            }
        }
    }

    private fun daysLeft(text: String): Int? {
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val end: Date = fmt.parse(text) ?: return null
            ((end.time - System.currentTimeMillis()) / 86400000L).toInt()
        } catch (e: Exception) {
            null
        }
    }
}
