from pathlib import Path
ROOT = Path(__file__).resolve().parent
proxy = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/database/ProxyGroup.kt").read_text()
db = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/database/SagerDatabase.kt").read_text()
helper = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/ReferenceSubscription.kt").read_text()
raw = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/RawUpdater.kt").read_text()
assert "starJumpBuiltIn: Boolean = false" in proxy
assert '@ColumnInfo(defaultValue = "0")' in proxy
assert "version = 8" in db and "Migration(6, 7)" in db and "Migration(7, 8)" in db
assert "output.writeInt(1)" in proxy and "output.writeBoolean(starJumpBuiltIn)" in proxy
assert "starJumpBuiltIn = version >= 1 && input.readBoolean()" in proxy
assert 'link = ""' in helper and 'backupLink = ""' in helper
assert 'starJumpBuiltIn = true' in helper
assert 'proxyGroup.isStarJumpReservedGroup()' in raw
assert 'ReferenceSubscription.sourceUrlFor(proxyGroup)' in raw
assert 'starjump://eight-degree' not in helper
print("PASS: built-in group identity uses a dedicated Room field")
print("PASS: database v6 -> v7 -> v8 explicit migration is declared")
print("PASS: built-in subscription URL and backup URL are empty in the database")
print("PASS: built-in updater chooses the hidden internal source by DB flag")
print("PASS: internal backup serialization v1 preserves the built-in flag and reads v0 backups")
