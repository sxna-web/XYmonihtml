#!/usr/bin/env python3
"""SQLite-level regression test for the 6.00.50 Room 6/7 -> 8 migration SQL."""
import json
import sqlite3
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB_SCHEMA = ROOT / "app/schemas/io.nekohasekai.sagernet.database.SagerDatabase/6.json"
DB_SOURCE = ROOT / "app/src/main/java/io/nekohasekai/sagernet/database/SagerDatabase.kt"
ENTITY_SOURCE = ROOT / "app/src/main/java/io/nekohasekai/sagernet/database/StarJumpEntitlementEntity.kt"
VAULT_SOURCE = ROOT / "app/src/main/java/io/nekohasekai/sagernet/starjump/StarJumpTokenVault.kt"
STORE_SOURCE = ROOT / "app/src/main/java/io/nekohasekai/sagernet/starjump/StarJumpEntitlementStore.kt"
API_SOURCE = ROOT / "app/src/main/java/io/nekohasekai/sagernet/starjump/StarJumpApi.kt"
PROPS = ROOT / "nb4a.properties"

schema = json.loads(DB_SCHEMA.read_text())["database"]
source = DB_SOURCE.read_text()
entity = ENTITY_SOURCE.read_text()
vault = VAULT_SOURCE.read_text()
store = STORE_SOURCE.read_text()
api = API_SOURCE.read_text()
props = PROPS.read_text()

assert "VERSION_NAME=6.00.50" in props and "VERSION_CODE=72" in props
assert "version = 8" in source
assert "Migration(6, 7)" in source and "Migration(7, 8)" in source
assert 'ALTER TABLE proxy_groups ADD COLUMN starJumpBuiltIn INTEGER NOT NULL DEFAULT 0' in source
assert 'CREATE TABLE IF NOT EXISTS starjump_entitlements' in source
assert ".fallbackToDestructiveMigration()" not in source
assert "tokenCiphertext" in entity and "@PrimaryKey" not in entity  # composite entity primary key is explicit in @Entity
assert 'primaryKeys = ["entitlementKey"]' in entity
assert 'AndroidKeyStore' in vault and 'AES/GCM/NoPadding' in vault
assert 'StarJumpTokenVault.decrypt(stored.tokenCiphertext) == legacyToken' in store
assert store.index('dao().upsert(row)') < store.index('remove("token")')
assert '"entitlement:$admin:$entitlementId"' in store
assert 'append("&token=")' in api and 'tokens.filter { it.isNotBlank() }.distinct()' in api


def make_v6_db(conn):
    for item in schema["entities"]:
        conn.execute(item["createSql"].replace("`${TABLE_NAME}`", f'`{item["tableName"]}`'))
    conn.execute("INSERT INTO proxy_groups (userOrder, ungrouped, name, type, `order`, isSelector, frontProxy, landingProxy) VALUES (1, 0, 'Keep Group', 1, 0, 0, -1, -1)")
    conn.execute("INSERT INTO proxy_entities (groupId, type, userOrder, tx, rx, status, ping, uuid) VALUES (1, 0, 1, 12, 34, 0, 55, 'keep-node')")
    conn.execute("INSERT INTO rules (name, config, userOrder, enabled, domains, ip, port, sourcePort, network, source, protocol, outbound, packages) VALUES ('Keep Rule', '', 1, 1, 'example.com', '', '', '', '', '', '', 0, '')")


def apply_6_to_7(conn):
    conn.execute("ALTER TABLE proxy_groups ADD COLUMN starJumpBuiltIn INTEGER NOT NULL DEFAULT 0")
    conn.execute("PRAGMA user_version = 7")


def apply_7_to_8(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS starjump_entitlements (entitlementKey TEXT NOT NULL, entitlementId TEXT, adminUserId TEXT NOT NULL, cardId TEXT, expiresAt TEXT, status TEXT NOT NULL, tokenCiphertext TEXT NOT NULL, lastVerifiedAt INTEGER, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(entitlementKey))")
    conn.execute("CREATE INDEX IF NOT EXISTS index_starjump_entitlements_adminUserId ON starjump_entitlements(adminUserId)")
    conn.execute("CREATE INDEX IF NOT EXISTS index_starjump_entitlements_cardId ON starjump_entitlements(cardId)")
    conn.execute("CREATE INDEX IF NOT EXISTS index_starjump_entitlements_status ON starjump_entitlements(status)")
    conn.execute("PRAGMA user_version = 8")

for start_version in (6, 7):
    with tempfile.NamedTemporaryFile(suffix=".db") as tmp:
        conn = sqlite3.connect(tmp.name)
        make_v6_db(conn)
        if start_version == 7:
            apply_6_to_7(conn)
        else:
            conn.execute("PRAGMA user_version = 6")
            apply_6_to_7(conn)
        apply_7_to_8(conn)
        assert conn.execute("PRAGMA user_version").fetchone()[0] == 8
        assert conn.execute("SELECT name FROM proxy_groups").fetchone()[0] == "Keep Group"
        assert conn.execute("SELECT uuid FROM proxy_entities").fetchone()[0] == "keep-node"
        assert conn.execute("SELECT name FROM rules").fetchone()[0] == "Keep Rule"
        assert conn.execute("SELECT starJumpBuiltIn FROM proxy_groups").fetchone()[0] == 0
        assert conn.execute("SELECT COUNT(*) FROM starjump_entitlements").fetchone()[0] == 0
        conn.close()

print("PASS: explicit Room 6->7->8 and 7->8 SQL preserve proxy_groups, proxy_entities, and rules")
print("PASS: entitlement table and indexes are created without destructive fallback")
print("PASS: Keystore AES-GCM and legacy write/readback-before-clear guards are present")
print("PASS: entitlement keys include admin identity and links send repeated token parameters")
