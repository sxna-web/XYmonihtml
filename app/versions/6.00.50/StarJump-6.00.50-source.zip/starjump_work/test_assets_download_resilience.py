#!/usr/bin/env python3
"""Regression checks for safe GeoIP/GeoSite build-asset downloads."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPT = (ROOT / "buildScript/lib/assets.sh").read_text()
WORKFLOW = (ROOT / ".github/workflows/starjump-arm64.yml").read_text()

assert "set -Eeuo pipefail" in SCRIPT
assert "--connect-timeout 20" in SCRIPT
assert "--max-time 240" in SCRIPT
assert "--retry 5" in SCRIPT
assert "--retry-max-time 240" in SCRIPT
assert "https://api.github.com/repos/${repository}/releases/latest" in SCRIPT
assert "json.load(source)" in SCRIPT
assert "re.fullmatch" in SCRIPT
assert "if [[ ! -s \"${db_file}\" ]]" in SCRIPT
assert 'if [[ "${label}" == "geoip" ]]' in SCRIPT
assert "MaxMind.com" in SCRIPT
assert 'xz --test "${xz_file}"' in SCRIPT
assert 'download_database "SagerNet/sing-geoip" "geoip"' in SCRIPT
assert 'download_database "SagerNet/sing-geosite" "geosite"' in SCRIPT
assert "rm -rf $DIR" not in SCRIPT
assert "Both assets are ready and validated" in SCRIPT
assert 'mv -f "${ASSET_DIR}/${name}.db.xz.tmp"' in SCRIPT
assert "actions/cache@v4" in WORKFLOW
assert "app/libs/libcore.aar" in WORKFLOW
assert "steps.libcore-cache.outputs.cache-hit != 'true'" in WORKFLOW
assert "versionCode='360' versionName='6.00.50'" in WORKFLOW
assert "application-label:'星跃'" in WORKFLOW
print("PASS: transient GitHub/API/download failures are retried with bounded timeouts")
print("PASS: release tags are parsed as JSON and validated before URL construction")
print("PASS: empty assets are rejected; GeoIP MaxMind and xz integrity are checked")
print("PASS: GeoSite is not incorrectly treated as a MaxMind database")
print("PASS: existing asset directory is not deleted before successful downloads")
print("PASS: both databases are staged before installation")
print("PASS: ARM64 workflow caches the LibCore AAR across failed build retries")
print("PASS: APK packaging checks actual version metadata, 星跃 label, and icon resources")
