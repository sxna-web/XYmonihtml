package io.nekohasekai.sagernet.starjump

import android.os.Bundle
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity

class TutorialActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val web = WebView(this)
        web.settings.javaScriptEnabled = false
        web.loadUrl("file:///android_asset/tutorial.html")
        setContentView(web)
    }
}
