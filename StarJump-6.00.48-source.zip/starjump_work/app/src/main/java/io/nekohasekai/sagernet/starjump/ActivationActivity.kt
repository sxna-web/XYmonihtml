package io.nekohasekai.sagernet.starjump

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import io.nekohasekai.sagernet.R
import java.util.UUID

class ActivationActivity : AppCompatActivity() {

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var codeInput: EditText
    private lateinit var statusText: TextView
    private lateinit var expireText: TextView
    private lateinit var linkBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_activation)
        prefs = getSharedPreferences("starjump", MODE_PRIVATE)

        codeInput = findViewById(R.id.cardCode)
        statusText = findViewById(R.id.statusText)
        expireText = findViewById(R.id.expireText)
        linkBox = findViewById(R.id.linkBox)

        findViewById<Button>(R.id.activateBtn).setOnClickListener { doActivate() }
        findViewById<Button>(R.id.bindBtn).setOnClickListener { askAdminCode() }

        refreshState()
        checkUpdate()
    }

    private fun deviceId(): String {
        var id = prefs.getString("device_id", null)
        if (id.isNullOrBlank()) {
            id = "d" + UUID.randomUUID().toString().replace("-", "")
            prefs.edit().putString("device_id", id).apply()
        }
        return id
    }

    private fun base(): String = prefs.getString("api_base", StarJumpApi.DEFAULT_BASE) ?: StarJumpApi.DEFAULT_BASE

    private fun refreshState() {
        val token = prefs.getString("token", null)
        val until = prefs.getString("expires_at", null)
        if (token.isNullOrBlank()) {
            statusText.text = getString(R.string.sj_not_activated)
            expireText.text = ""
            linkBox.removeAllViews()
            return
        }
        statusText.text = getString(R.string.sj_activated)
        expireText.text = getString(R.string.sj_expire_at, until ?: "-")
        loadLinks(token)
    }

    private fun loadLinks(token: String) {
        Thread {
            val list = StarJumpApi.links(base(), deviceId(), token)
            runOnUiThread {
                linkBox.removeAllViews()
                if (list.isEmpty()) return@runOnUiThread
                val title = TextView(this)
                title.text = getString(R.string.sj_links_title)
                title.textSize = 15f
                linkBox.addView(title)
                for (item in list) {
                    val b = Button(this)
                    b.text = item.title
                    b.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.url))) }
                    linkBox.addView(b)
                }
            }
        }.start()
    }

    private fun doActivate() {
        val code = codeInput.text.toString().trim().uppercase()
        if (code.isEmpty()) {
            toast(getString(R.string.sj_card_empty)); return
        }
        statusText.text = getString(R.string.sj_activating)
        Thread {
            val r = StarJumpApi.redeem(base(), code, deviceId())
            runOnUiThread {
                if (r.ok) {
                    prefs.edit()
                        .putString("token", r.token)
                        .putString("expires_at", r.expiresAt)
                        .putString("admin_user_id", r.adminUserId)
                        .apply()
                    statusText.text = getString(R.string.sj_activate_ok, r.days)
                    expireText.text = getString(R.string.sj_expire_at, r.expiresAt ?: "-")
                    loadLinks(r.token ?: "")
                } else {
                    statusText.text = r.error ?: getString(R.string.sj_activate_failed)
                }
            }
        }.start()
    }

    private fun askAdminCode() {
        val input = EditText(this)
        input.hint = getString(R.string.sj_admin_code_hint)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        AlertDialog.Builder(this)
            .setTitle(R.string.sj_bind_admin)
            .setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val code = input.text.toString().trim().uppercase()
                if (code.length < 4) { toast(getString(R.string.sj_admin_code_invalid)); return@setPositiveButton }
                Thread {
                    val r = StarJumpApi.resolve(base(), code)
                    runOnUiThread {
                        if (r.ok) {
                            prefs.edit().putString("admin_code", code).putString("admin_user_id", r.adminUserId).apply()
                            toast(getString(R.string.sj_bind_ok, r.adminName ?: code))
                        } else {
                            toast(r.error ?: getString(R.string.sj_admin_code_invalid))
                        }
                    }
                }.start()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun checkUpdate() {
        Thread {
            val info = StarJumpApi.version(base(), 60047)
            runOnUiThread {
                if (info == null || !info.optBoolean("update")) return@runOnUiThread
                val force = info.optBoolean("force")
                val builder = AlertDialog.Builder(this)
                    .setTitle(getString(R.string.sj_update_title))
                    .setMessage(info.optString("notes"))
                    .setPositiveButton(R.string.sj_update_now) { _, _ ->
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(info.optString("url"))))
                    }
                    .setCancelable(!force)
                if (!force) builder.setNegativeButton(android.R.string.cancel, null)
                builder.show()
            }
        }.start()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
