package io.nekohasekai.sagernet.starjump

import android.app.Activity
import android.content.Intent
import android.view.View
import com.google.android.material.snackbar.Snackbar
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 启动检查：未激活 / 即将到期 / 已过期。
 * 不做全屏弹窗，只弹一次引导 + 底部提示条（不打断使用）。
 */
object StarJumpGate {

    private const val PREFS = "starjump"

    fun check(activity: Activity, root: View) {
        val prefs = activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE)
        val token = prefs.getString("token", null)
        if (token.isNullOrBlank()) {
            val guided = prefs.getBoolean("guided", false)
            if (!guided) {
                prefs.edit().putBoolean("guided", true).apply()
                activity.startActivity(Intent(activity, ActivationActivity::class.java))
            } else {
                Snackbar.make(root, "尚未激活卡密", Snackbar.LENGTH_INDEFINITE)
                    .setAction("去激活") {
                        activity.startActivity(Intent(activity, ActivationActivity::class.java))
                    }
                    .show()
            }
            return
        }

        val until = prefs.getString("expires_at", null) ?: return
        val days = daysLeft(until)
        if (days == null) return
        if (days < 0) {
            Snackbar.make(root, "卡密已过期，节点已停止更新", Snackbar.LENGTH_INDEFINITE)
                .setAction("续费") {
                    activity.startActivity(Intent(activity, ActivationActivity::class.java))
                }
                .show()
        } else if (days <= 3) {
            Snackbar.make(root, "卡密还有 $days 天到期", Snackbar.LENGTH_LONG)
                .setAction("续费") {
                    activity.startActivity(Intent(activity, ActivationActivity::class.java))
                }
                .show()
        }
    }

    private fun daysLeft(text: String): Int? {
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val end: Date = fmt.parse(text) ?: return null
            ((end.time - System.currentTimeMillis()) / 86400000L).toInt()
        } catch (e: Exception) {
            null
        }
    }
}
