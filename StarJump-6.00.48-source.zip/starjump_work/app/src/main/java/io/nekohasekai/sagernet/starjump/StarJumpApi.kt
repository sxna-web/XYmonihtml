package io.nekohasekai.sagernet.starjump

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** 与星跃后端通信的最小实现，不引入额外依赖。 */
object StarJumpApi {

    // 默认服务地址；用户可在激活页修改并保存
    const val DEFAULT_BASE = "https://starjump-api-staging.synahcoo.workers.dev"

    data class RedeemResult(
        val ok: Boolean,
        val token: String?,
        val adminUserId: String?,
        val expiresAt: String?,
        val days: Int,
        val error: String?
    )

    data class ResolveResult(val ok: Boolean, val adminUserId: String?, val adminName: String?, val freeEnabled: Boolean, val error: String?)

    data class LinkItem(val title: String, val url: String)

    private fun open(urlStr: String, method: String, body: String?): Pair<Int, String> {
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 10000
        conn.readTimeout = 15000
        conn.setRequestProperty("Accept", "application/json")
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.use { s ->
            BufferedReader(InputStreamReader(s, Charsets.UTF_8)).readText()
        } ?: ""
        conn.disconnect()
        return code to text
    }

    fun redeem(base: String, code: String, deviceId: String): RedeemResult {
        return try {
            val body = JSONObject().put("code", code).put("device_id", deviceId).toString()
            val (status, text) = open("$base/api/app/redeem", "POST", body)
            val json = JSONObject(text)
            if (status == 201 && json.optBoolean("ok")) {
                val data = json.getJSONObject("data")
                val ent = data.getJSONObject("entitlement")
                RedeemResult(true, data.optString("token"), data.optString("admin_user_id"),
                    ent.optString("expires_at"), data.optInt("days"), null)
            } else {
                RedeemResult(false, null, null, null, 0, json.optString("error", "激活失败"))
            }
        } catch (e: Exception) {
            RedeemResult(false, null, null, null, 0, "网络错误：" + (e.message ?: "未知"))
        }
    }

    fun resolve(base: String, code: String): ResolveResult {
        return try {
            val (status, text) = open("$base/api/app/resolve?code=$code", "GET", null)
            val json = JSONObject(text)
            if (status == 200 && json.optBoolean("ok")) {
                val d = json.getJSONObject("data")
                ResolveResult(true, d.optString("admin_user_id"), d.optString("admin_name"), d.optBoolean("free_group_enabled"), null)
            } else {
                ResolveResult(false, null, null, false, json.optString("error", "编号无效"))
            }
        } catch (e: Exception) {
            ResolveResult(false, null, null, false, "网络错误：" + (e.message ?: "未知"))
        }
    }

    fun links(base: String, deviceId: String, token: String): List<LinkItem> {
        return try {
            val (status, text) = open("$base/api/app/links?device_id=$deviceId&token=$token", "GET", null)
            if (status != 200) return emptyList()
            val arr = JSONObject(text).optJSONArray("data") ?: return emptyList()
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                LinkItem(o.optString("title"), o.optString("url"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun version(base: String, current: Int): JSONObject? {
        return try {
            val (status, text) = open("$base/api/app/version?platform=android&current=$current", "GET", null)
            if (status != 200) null else JSONObject(text).optJSONObject("data")
        } catch (e: Exception) { null }
    }
}
