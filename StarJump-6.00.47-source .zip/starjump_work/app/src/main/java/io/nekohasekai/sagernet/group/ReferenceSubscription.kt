package io.nekohasekai.sagernet.group

import io.nekohasekai.sagernet.GroupOrder
import io.nekohasekai.sagernet.GroupType
import io.nekohasekai.sagernet.database.DataStore
import io.nekohasekai.sagernet.database.GroupManager
import io.nekohasekai.sagernet.database.ProxyGroup
import io.nekohasekai.sagernet.database.SagerDatabase
import io.nekohasekai.sagernet.database.SubscriptionBean

/** Five independent app-managed StarJump subscription slots. */
object ReferenceSubscription {
    // Keep these as obvious, one-line constants so they can be replaced in the APK
    // with MT Manager when the remaining Paste.gg sources are supplied.
    private const val SLOT_01_URL =
        "https://paste.gg/p/xh/e08d0acaa7af4e7ca654cd938e0ba623/files/1940d97d791e432c960a5190d533abba/raw"
    private const val SLOT_02_URL = "PASTE_GG_URL_SLOT_02"
    private const val SLOT_03_URL = "PASTE_GG_URL_SLOT_03"
    private const val SLOT_04_URL = "PASTE_GG_URL_SLOT_04"
    private const val SLOT_05_URL = "PASTE_GG_URL_SLOT_05"

    private data class Slot(val number: Int, val name: String, val url: String)

    private val slots = listOf(
        Slot(1, "星跃节点 01", SLOT_01_URL),
        Slot(2, "星跃节点 02", SLOT_02_URL),
        Slot(3, "星跃节点 03", SLOT_03_URL),
        Slot(4, "星跃节点 04", SLOT_04_URL),
        Slot(5, "星跃节点 05", SLOT_05_URL)
    )

    // Exact legacy marker from previous builds. Match the URL only for migration;
    // never claim an unrelated user-created group based on its display name.
    private const val LEGACY_RAW_URL = ProxyGroup.STARJUMP_LEGACY_LINK

    /** Returns the immutable source assigned to this reserved group, or blank if not configured. */
    fun sourceUrlFor(group: ProxyGroup): String? {
        if (!group.isStarJumpReservedGroup()) return null
        return slots.firstOrNull { it.name == group.name }?.url
            ?.takeIf { it.startsWith("https://", ignoreCase = true) }
    }

    /** True for one of the five reserved StarJump slots, including unconfigured slots. */
    fun isSlot(group: ProxyGroup): Boolean =
        group.isStarJumpReservedGroup() && slots.any { it.name == group.name }

    /**
     * Idempotently creates all five independent groups. The former single
     * "星跃节点" group is renamed to slot 01 in place, preserving its ID and nodes.
     */
    suspend fun ensureGroups(): List<ProxyGroup> {
        val allSubscriptions = SagerDatabase.groupDao.subscriptions()
        val reserved = allSubscriptions.filter { it.isStarJumpReservedGroup() }
        val legacy = allSubscriptions.firstOrNull { it.subscription?.link?.trim() == LEGACY_RAW_URL }

        val byName = reserved.associateBy { it.name }
        val firstExisting = byName[slots[0].name]
            ?: legacy
            ?: reserved.firstOrNull { it.name == "星跃节点" }
        val result = ArrayList<ProxyGroup>(slots.size)
        val usedGroupIds = HashSet<Long>()
        var createdFirst = false

        for (slot in slots) {
            val candidate = if (slot.number == 1) firstExisting else byName[slot.name]
            val existing = candidate?.takeIf { usedGroupIds.add(it.id) }
            val group = if (existing != null) {
                existing.name = slot.name
                existing.type = GroupType.SUBSCRIPTION
                existing.starJumpBuiltIn = true
                val bean = existing.subscription ?: SubscriptionBean()
                bean.apply {
                    // Sources live in this APK configuration, not editable DB URLs.
                    // This prevents stale legacy URLs or user edits from cross-wiring slots.
                    link = ""
                    backupLink = ""
                    autoUpdate = false
                    updateWhenConnectedOnly = false
                }
                existing.subscription = bean
                SagerDatabase.groupDao.updateGroup(existing)
                existing
            } else {
                val bean = SubscriptionBean().apply {
                    link = ""
                    backupLink = ""
                    autoUpdate = false
                    updateWhenConnectedOnly = false
                }
                GroupManager.createGroup(
                    ProxyGroup(
                        name = slot.name,
                        type = GroupType.SUBSCRIPTION,
                        starJumpBuiltIn = true,
                        order = GroupOrder.BY_DELAY,
                        subscription = bean
                    )
                ).also {
                    if (slot.number == 1) createdFirst = true
                }
            }
            usedGroupIds.add(group.id)
            result += group
        }

        // Match previous first-install behavior without overriding a user's later choice.
        if (createdFirst) {
            DataStore.selectedGroup = result.first().id
            DataStore.selectedProxy = 0L
            DataStore.selectedProxyManuallyChosen = false
        }
        return result
    }
}
