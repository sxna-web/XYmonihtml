package io.nekohasekai.sagernet.group

import android.util.Base64
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PublicKey
import java.security.Signature
import java.security.interfaces.RSAPublicKey
import java.security.spec.X509EncodedKeySpec

/** Verifies NBX signed subscriptions, planned key rotation, and offline-root recovery. */
internal object SubscriptionSignature {

    data class VerifiedPayload(
        val content: String,
        val version: Long,
        val sha256: String,
        val rotatedPublicKey: String?
    )

    private const val FORMAT = "nbx-subscription-v1"
    private const val MAX_FUTURE_SKEW_SECONDS = 300L
    private const val MAX_VALIDITY_SECONDS = 90L * 24L * 60L * 60L
    private const val MIN_RSA_BITS = 2048

    fun unwrap(
        response: String,
        publicKeyBase64: String,
        recoveryPublicKeyBase64: String,
        previousVersion: Long,
        previousHash: String
    ): VerifiedPayload {
        require(publicKeyBase64.isNotBlank()) { "Signing public key is missing" }
        val envelope = JSONObject(response)
        require(envelope.optString("format") == FORMAT) { "Unsupported signed subscription format" }

        val version = envelope.getLong("version")
        val issuedAt = envelope.getLong("issued_at")
        val expiresAt = envelope.getLong("expires_at")
        val now = System.currentTimeMillis() / 1000L
        require(version > 0L) { "Invalid signed subscription version" }
        require(issuedAt <= now + MAX_FUTURE_SKEW_SECONDS) {
            "Signed subscription issue time is in the future"
        }
        require(expiresAt > now && expiresAt > issuedAt) {
            "Signed subscription has expired or invalid validity period"
        }
        require(expiresAt - issuedAt <= MAX_VALIDITY_SECONDS) {
            "Signed subscription validity period is too long"
        }

        val payloadBytes = Base64.decode(envelope.getString("payload"), Base64.DEFAULT)
        require(payloadBytes.isNotEmpty()) { "Signed subscription payload is empty" }
        val payloadHash = sha256(payloadBytes)

        val currentKeyBytes = Base64.decode(publicKeyBase64.trim(), Base64.DEFAULT)
        val currentKey = parseRsaPublicKey(currentKeyBytes, "Subscription")
        val recoveryObject = envelope.optJSONObject("key_recovery")
        val effectiveKey: PublicKey
        val recoveredKeyBase64: String?

        if (recoveryObject != null) {
            require(recoveryPublicKeyBase64.isNotBlank()) {
                "Emergency key recovery was supplied but no offline recovery key is pinned"
            }
            require(!envelope.has("key_rotation")) {
                "Normal rotation and emergency recovery cannot be combined"
            }
            val replacementBytes = Base64.decode(
                recoveryObject.getString("new_public_key").trim(), Base64.DEFAULT
            )
            require(replacementBytes.isNotEmpty()) { "Recovery replacement key is empty" }
            require(!MessageDigest.isEqual(currentKeyBytes, replacementBytes)) {
                "Recovery replacement key is identical to the current key"
            }
            val replacementKey = parseRsaPublicKey(replacementBytes, "Recovery replacement")
            val replacementFingerprint = sha256(replacementBytes)
            val recoveryMessage = recoveryMessage(
                replacementFingerprint, version, issuedAt, expiresAt, payloadHash
            )
            val recoverySignature = Base64.decode(
                recoveryObject.getString("signature"), Base64.DEFAULT
            )
            val recoveryKey = parseRsaPublicKey(
                Base64.decode(recoveryPublicKeyBase64.trim(), Base64.DEFAULT), "Offline recovery"
            )
            verifySignature(recoveryKey, recoveryMessage, recoverySignature,
                "Offline recovery authorization failed")
            effectiveKey = replacementKey
            recoveredKeyBase64 = Base64.encodeToString(replacementBytes, Base64.NO_WRAP)
        } else {
            effectiveKey = currentKey
            recoveredKeyBase64 = null
        }

        val signedMessage = "$FORMAT\n$version\n$issuedAt\n$expiresAt\n$payloadHash"
            .toByteArray(StandardCharsets.UTF_8)
        val signatureBytes = Base64.decode(envelope.getString("signature"), Base64.DEFAULT)
        verifySignature(effectiveKey, signedMessage, signatureBytes,
            "Subscription signature verification failed")

        // A planned rotation is authorized by the currently pinned online key.
        val rotatedPublicKey = if (recoveredKeyBase64 != null) {
            recoveredKeyBase64
        } else {
            verifyKeyRotation(envelope, currentKey, currentKeyBytes)
        }

        require(version >= previousVersion) { "Subscription version rollback rejected" }
        if (recoveredKeyBase64 != null) {
            require(version > previousVersion) {
                "Emergency key recovery must increase the subscription version"
            }
        }
        if (version == previousVersion && previousVersion > 0L) {
            require(payloadHash.equals(previousHash, ignoreCase = true)) {
                "Subscription content changed without increasing its version"
            }
        }

        return VerifiedPayload(
            String(payloadBytes, StandardCharsets.UTF_8), version, payloadHash, rotatedPublicKey
        )
    }

    private fun verifyKeyRotation(
        envelope: JSONObject,
        currentKey: PublicKey,
        currentKeyBytes: ByteArray
    ): String? {
        if (!envelope.has("key_rotation") || envelope.isNull("key_rotation")) return null
        val rotation = envelope.getJSONObject("key_rotation")
        val nextKeyBytes = Base64.decode(rotation.getString("public_key").trim(), Base64.DEFAULT)
        require(nextKeyBytes.isNotEmpty()) { "Rotated subscription public key is empty" }
        require(!MessageDigest.isEqual(currentKeyBytes, nextKeyBytes)) {
            "Rotated subscription key is identical to the current key"
        }
        parseRsaPublicKey(nextKeyBytes, "Rotated subscription")
        val rotationMessage = "nbx-key-rotation-v1\n${sha256(nextKeyBytes)}"
            .toByteArray(StandardCharsets.UTF_8)
        val rotationSignature = Base64.decode(rotation.getString("signature"), Base64.DEFAULT)
        verifySignature(currentKey, rotationMessage, rotationSignature,
            "Subscription key rotation signature failed")
        return Base64.encodeToString(nextKeyBytes, Base64.NO_WRAP)
    }

    private fun parseRsaPublicKey(encoded: ByteArray, label: String): PublicKey {
        require(encoded.isNotEmpty()) { "$label public key is empty" }
        val key = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(encoded))
        val bits = (key as? RSAPublicKey)?.modulus?.bitLength() ?: 0
        require(bits >= MIN_RSA_BITS) { "$label RSA key must be at least $MIN_RSA_BITS bits" }
        return key
    }

    private fun verifySignature(
        key: PublicKey,
        message: ByteArray,
        signatureBytes: ByteArray,
        failureMessage: String
    ) {
        val verifier = Signature.getInstance("SHA256withRSA")
        verifier.initVerify(key)
        verifier.update(message)
        require(verifier.verify(signatureBytes)) { failureMessage }
    }

    private fun recoveryMessage(
        fingerprint: String,
        version: Long,
        issuedAt: Long,
        expiresAt: Long,
        payloadHash: String
    ): ByteArray = "nbx-key-recovery-v1\n$fingerprint\n$version\n$issuedAt\n$expiresAt\n$payloadHash"
        .toByteArray(StandardCharsets.UTF_8)

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes)
        .joinToString("") { "%02x".format(it) }
}
