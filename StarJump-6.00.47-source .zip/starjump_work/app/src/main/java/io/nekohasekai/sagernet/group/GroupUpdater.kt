package io.nekohasekai.sagernet.group

import io.nekohasekai.sagernet.*
import io.nekohasekai.sagernet.database.DataStore
import io.nekohasekai.sagernet.database.GroupManager
import io.nekohasekai.sagernet.database.ProxyGroup
import io.nekohasekai.sagernet.database.SagerDatabase
import io.nekohasekai.sagernet.database.SubscriptionBean
import io.nekohasekai.sagernet.fmt.AbstractBean
import io.nekohasekai.sagernet.fmt.http.HttpBean
import io.nekohasekai.sagernet.fmt.hysteria.HysteriaBean
import io.nekohasekai.sagernet.fmt.naive.NaiveBean
import io.nekohasekai.sagernet.fmt.trojan.TrojanBean
import io.nekohasekai.sagernet.fmt.trojan_go.TrojanGoBean
import io.nekohasekai.sagernet.fmt.v2ray.StandardV2RayBean
import io.nekohasekai.sagernet.fmt.v2ray.isTLS
import io.nekohasekai.sagernet.ktx.*
import kotlinx.coroutines.*
import java.net.Inet4Address
import java.net.InetAddress
import java.util.*
import java.util.concurrent.atomic.AtomicInteger

@Suppress("EXPERIMENTAL_API_USAGE")
abstract class GroupUpdater {

    abstract suspend fun doUpdate(
        proxyGroup: ProxyGroup,
        subscription: SubscriptionBean,
        userInterface: GroupManager.Interface?,
        byUser: Boolean
    )

    data class Progress(
        var max: Int
    ) {
        var progress by AtomicInteger()
    }

    protected suspend fun forceResolve(
        profiles: List<AbstractBean>, groupId: Long?
    ) {
        val ipv6Mode = DataStore.ipv6Mode
        val isStarJumpGroup = groupId?.let {
            SagerDatabase.groupDao.getById(it)?.isStarJumpReservedGroup() == true
        } == true
        val progress = Progress(profiles.size)
        if (groupId != null) {
            GroupUpdater.progress[groupId] = progress
            GroupManager.postReload(groupId)
        }
        val ipv6First = ipv6Mode >= IPv6Mode.PREFER
        val lookupPool = newFixedThreadPoolContext(5, "DNS Lookup")

        // Keep DNS lookups as children of this refresh operation. The old
        // GlobalScope jobs survived cancellation and could keep the temporary
        // executor alive after the subscription update had already failed.
        try {
            coroutineScope {
                val lookupJobs = profiles.mapNotNull { profile ->
                    when (profile) {
                        // SNI rewrite unsupported
                        is NaiveBean -> return@mapNotNull null
                    }

                    if (profile.serverAddress.isIpAddress()) return@mapNotNull null

                    launch(lookupPool) {
                        try {
                            val results = if (
                                SagerNet.underlyingNetwork != null &&
                                DataStore.enableFakeDns &&
                                DataStore.serviceState.started &&
                                DataStore.serviceMode == Key.MODE_VPN
                            ) {
                                // FakeDNS
                                SagerNet.underlyingNetwork!!
                                    .getAllByName(profile.serverAddress)
                                    .filterNotNull()
                            } else {
                                // System DNS is enough (when VPN connected, it uses v2ray-core)
                                InetAddress.getAllByName(profile.serverAddress).filterNotNull()
                            }
                            if (results.isEmpty()) error("empty response")
                            rewriteAddress(profile, results, ipv6First)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            if (isStarJumpGroup) {
                                Logs.d("StarJump node DNS lookup failed (${e.javaClass.simpleName})")
                            } else {
                                Logs.d("Lookup ${profile.serverAddress} failed: ${e.readableMessage}", e)
                            }
                        }
                        if (groupId != null) {
                            progress.progress++
                            GroupManager.postReload(groupId)
                        }
                    }
                }
                lookupJobs.joinAll()
            }
        } finally {
            lookupPool.close()
        }
    }

    protected fun rewriteAddress(
        bean: AbstractBean, addresses: List<InetAddress>, ipv6First: Boolean
    ) {
        val address = addresses.sortedBy { (it is Inet4Address) xor ipv6First }[0].hostAddress

        with(bean) {
            when (this) {
                is HttpBean -> {
                    if (isTLS() && sni.isBlank()) sni = bean.serverAddress
                }
                is StandardV2RayBean -> {
                    when (security) {
                        "tls" -> if (sni.isBlank()) sni = bean.serverAddress
                    }
                }
                is TrojanBean -> {
                    if (sni.isBlank()) sni = bean.serverAddress
                }
                is TrojanGoBean -> {
                    if (sni.isBlank()) sni = bean.serverAddress
                }
                is HysteriaBean -> {
                    if (sni.isBlank()) sni = bean.serverAddress
                }
            }

            bean.serverAddress = address
        }
    }

    companion object {

        val updating = Collections.synchronizedSet<Long>(mutableSetOf())
        val progress = Collections.synchronizedMap<Long, Progress>(mutableMapOf())

        fun startUpdate(proxyGroup: ProxyGroup, byUser: Boolean) {
            runOnDefaultDispatcher {
                executeUpdate(proxyGroup, byUser)
            }
        }

        suspend fun executeUpdate(proxyGroup: ProxyGroup, byUser: Boolean): Boolean {
            return coroutineScope {
                if (!updating.add(proxyGroup.id)) cancel()
                executeUpdateClaimed(proxyGroup, byUser)
            }
        }

        /**
         * Startup/background callers must never cancel a refresh already started by
         * the user or another worker. The synchronized-set add is the atomic claim.
         * Returns false when another refresh already owns this group.
         */
        suspend fun executeUpdateIfIdle(proxyGroup: ProxyGroup, byUser: Boolean): Boolean {
            if (!updating.add(proxyGroup.id)) return false
            return executeUpdateClaimed(proxyGroup, byUser)
        }

        private suspend fun executeUpdateClaimed(
            proxyGroup: ProxyGroup,
            byUser: Boolean
        ): Boolean {
            try {
                // Everything after the update claim belongs inside this protected
                // lifecycle, including UI confirmation and the initial reload event.
                GroupManager.postReload(proxyGroup.id)

                val subscription = proxyGroup.subscription ?: return false
                val connected = DataStore.serviceState.connected
                val userInterface = GroupManager.userInterface

                // The built-in StarJump reference source is HTTPS. For ordinary
                // user subscriptions, preserve the normal HTTP confirmation warning.
                val hasCleartextEndpoint = listOf(subscription.link, subscription.backupLink)
                    .filterNotNull()
                    .any { it.trim().startsWith("http://", ignoreCase = true) }
                val requiresConnectionWarning = subscription.updateWhenConnectedOnly && !connected
                if (byUser && (hasCleartextEndpoint || requiresConnectionWarning)) {
                    if (userInterface == null || !userInterface.confirm(app.getString(R.string.update_subscription_warning))) {
                        return true
                    }
                }

                RawUpdater.doUpdate(proxyGroup, subscription, userInterface, byUser)
                return true
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                if (proxyGroup.isStarJumpReservedGroup()) {
                    Logs.w("StarJump subscription update failed (${e.javaClass.simpleName})")
                } else {
                    Logs.w(e)
                }
                try {
                    GroupManager.userInterface?.onUpdateFailure(proxyGroup, e.readableMessage)
                } catch (callbackError: Throwable) {
                    if (callbackError is CancellationException) throw callbackError
                    Logs.w(callbackError)
                }
                return false
            } finally {
                // One owner performs cleanup for success, rejection, exceptions,
                // and coroutine cancellation. Never leave the group permanently busy.
                finishUpdate(proxyGroup)
            }
        }

        suspend fun finishUpdate(proxyGroup: ProxyGroup) {
            // Release the ownership flags before notifying UI listeners. The
            // notification must also run when the parent refresh was cancelled;
            // otherwise a cancelled coroutine can leave the screen showing stale
            // progress even though the group is no longer updating.
            updating.remove(proxyGroup.id)
            progress.remove(proxyGroup.id)
            try {
                withContext(NonCancellable) {
                    GroupManager.postUpdate(proxyGroup)
                }
            } catch (e: Exception) {
                // A broken UI listener must not turn a completed refresh into a
                // failed refresh or prevent the caller's cancellation from
                // propagating. The update lock and progress state are already clear.
                Logs.w(e)
            }
        }

    }

}