package io.nekohasekai.sagernet.bg

import io.nekohasekai.sagernet.SagerNet
import io.nekohasekai.sagernet.database.DataStore
import io.nekohasekai.sagernet.database.GroupManager
import io.nekohasekai.sagernet.database.ProfileManager
import io.nekohasekai.sagernet.database.SagerDatabase
import io.nekohasekai.sagernet.group.GroupUpdater
import io.nekohasekai.sagernet.group.ReferenceSubscription
import io.nekohasekai.sagernet.bg.proto.UrlTest
import io.nekohasekai.sagernet.ktx.Logs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay

/** Refreshes every configured remote subscription, then tests the selected group once per app process start. */
object AutoNodeStartup {
    suspend fun refreshAndTestSelectedGroup() {
        // A manual test may already own the shared gate when MainActivity starts.
        // Wait briefly rather than silently dropping the one-shot startup task.
        var gateAcquired = false
        var gateAttempts = 0
        while (!gateAcquired && gateAttempts < 60) {
            gateAcquired = DataStore.tryStartRunningTest()
            if (!gateAcquired) delay(500)
            gateAttempts++
        }
        if (!gateAcquired) {
            GroupManager.userInterface?.onStartupRefreshProgress(
                "其他测速任务仍在进行，请稍后手动刷新", true
            )
            return
        }
        try {
            withContext(Dispatchers.IO) {
                // Ensure the normal ungrouped/basic bucket exists first (fresh installs
                // rely on it for ordinary imports), then create the reference subscription
                // bucket and select it only on first creation.
                DataStore.currentGroup()
                val referenceGroups = ReferenceSubscription.ensureGroups()
                val group = DataStore.currentGroup()
                val groupId = group.id

                // Apply delay sorting to groups that predate this default exactly once.
                // After migration, a user's explicit sorting choice remains persistent.
                if (!DataStore.delaySortDefaultsApplied) {
                    val existingGroups = SagerDatabase.groupDao.allGroups()
                    for (existingGroup in existingGroups) {
                        if (existingGroup.order != io.nekohasekai.sagernet.GroupOrder.BY_DELAY) {
                            existingGroup.order = io.nekohasekai.sagernet.GroupOrder.BY_DELAY
                            SagerDatabase.groupDao.updateGroup(existingGroup)
                        }
                    }
                    DataStore.delaySortDefaultsApplied = true
                    existingGroups.forEach { GroupManager.postReload(it.id) }
                }
                // Remember the user's choice. If it changes while testing, never override it.
                val selectedAtStart = DataStore.selectedProxy

                // Only the dedicated built-in group uses the EightDegree-compatible source.
                // Do not overwrite or refresh unrelated user subscriptions.
                val configuredSubscriptions = referenceGroups.filter {
                    !ReferenceSubscription.sourceUrlFor(it).isNullOrBlank()
                }
                if (configuredSubscriptions.isNotEmpty()) {
                    GroupManager.userInterface?.onStartupRefreshProgress(
                        "正在更新星跃节点（${configuredSubscriptions.size}/5）…"
                    )
                }
                var refreshedCount = 0
                var failedCount = 0
                for (subscriptionGroup in configuredSubscriptions) {
                    try {
                        // Atomic claim: never invoke executeUpdate() for a group already
                        // being refreshed, because that API intentionally cancels duplicates.
                        if (GroupUpdater.executeUpdateIfIdle(subscriptionGroup, false)) {
                            refreshedCount++
                        } else if (GroupUpdater.updating.contains(subscriptionGroup.id)) {
                            // A user/background refresh already owns this group; do not cancel it
                            // and do not misreport it as a failed network download.
                            Logs.d("Startup subscription refresh already running; leaving it untouched")
                        } else {
                            // executeUpdateIfIdle returns false after GroupUpdater has handled
                            // and reported a download/parse failure. Count it so the startup
                            // status accurately says that saved nodes are being used as fallback.
                            failedCount++
                            Logs.w("Startup subscription refresh returned failure for group ${subscriptionGroup.id}")
                        }
                    } catch (e: kotlinx.coroutines.CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        failedCount++
                        // One unavailable source must not block the other StarJump slots
                        // or prevent testing the last saved nodes in the selected group.
                        Logs.w("Automatic subscription refresh failed for group ${subscriptionGroup.id}", e)
                    }
                }
                if (configuredSubscriptions.isNotEmpty()) {
                    val resultMessage = when {
                        refreshedCount > 0 && failedCount > 0 -> "星跃节点更新完成：成功 $refreshedCount 组，失败 $failedCount 组；正在测试节点…"
                        refreshedCount > 0 -> "星跃节点更新完成：成功 $refreshedCount 组，正在测试节点…"
                        failedCount > 0 -> "星跃节点更新失败，正在使用各组本地已有节点…"
                        else -> "没有已配置的星跃备用链接，正在测试本地节点…"
                    }
                    GroupManager.userInterface?.onStartupRefreshProgress(resultMessage)
                }

                // Do not test a different group if the user changed groups during refresh.
                if (DataStore.currentGroupId() != groupId) {
                    GroupManager.userInterface?.onStartupRefreshProgress(
                        "订阅获取已完成，当前分组已变化", true
                    )
                    return@withContext
                }
                val profiles = SagerDatabase.proxyDao.getByGroup(groupId)
                if (profiles.isEmpty()) {
                    GroupManager.userInterface?.onStartupRefreshProgress(
                        "没有获取到节点，请检查订阅地址或网络", true
                    )
                    return@withContext
                }

                val concurrency = DataStore.connectionTestConcurrent.coerceIn(1, 10)
                val semaphore = Semaphore(concurrency)
                coroutineScope {
                    profiles.map { profile ->
                        async(Dispatchers.IO) {
                            semaphore.withPermit {
                                profile.status = 0
                                profile.error = null
                                try {
                                    // Uses the same per-node sing-box URL test as manual real-connection testing.
                                    profile.ping = UrlTest().doTest(profile)
                                    // Libcore.urlTest returns -1 when the real URL request fails
                                    // without throwing; do not mark that result as usable.
                                    profile.status = if (profile.ping >= 0) 1 else 3
                                    if (profile.ping < 0) {
                                        profile.error = "URL 连通性测试失败"
                                    }
                                } catch (e: kotlinx.coroutines.CancellationException) {
                                    throw e
                                } catch (e: Exception) {
                                    profile.ping = -1
                                    profile.status = 3
                                    profile.error = e.message?.take(240)
                                    Logs.w("Automatic node connectivity test failed", e)
                                }
                                try {
                                    ProfileManager.updateProfile(profile)
                                } catch (e: Exception) {
                                    Logs.w("Unable to save automatic node test result", e)
                                }
                            }
                        }
                    }.awaitAll()
                }
                GroupManager.postReload(groupId)

                // Respect an explicit manual choice. Otherwise, select the first node
                // after URL testing has established delay order on every app launch.
                val selectedNow = DataStore.selectedProxy
                val hasValidManualSelection = DataStore.selectedProxyManuallyChosen &&
                    profiles.any { it.id == selectedNow && it.groupId == groupId }
                if (!hasValidManualSelection) {
                    // Never select an unverified/failed profile as the automatic default.
                    // If every test failed, preserve the existing selection so the UI does
                    // not imply that a dead node is the best available choice.
                    val firstUsableNode = profiles
                        .asSequence()
                        .filter { it.groupId == groupId && it.status == 1 && it.ping >= 0 }
                        .minByOrNull { it.ping }
                    if (firstUsableNode != null) {
                        DataStore.selectedProxy = firstUsableNode.id
                        DataStore.selectedProxyManuallyChosen = false
                        Logs.i("No valid manual node choice; selected the fastest confirmed usable node")
                    } else {
                        Logs.w("No usable node was confirmed; keeping the existing node selection")
                    }
                }

                // Fail over only when the node that was selected before testing is still
                // selected, belongs to this group, and has a confirmed URL-test failure.
                // A manual selection made during testing always wins.
                val selectedAfterTest = DataStore.selectedProxy
                if (selectedAtStart != 0L && selectedAfterTest == selectedAtStart &&
                    DataStore.serviceState.started) {
                    val selectedProfile = profiles.firstOrNull { it.id == selectedAtStart }
                    if (selectedProfile != null && selectedProfile.groupId == groupId &&
                        (selectedProfile.status != 1 || selectedProfile.ping < 0)) {
                        val fallback = profiles.asSequence()
                            .filter { it.id != selectedAtStart && it.groupId == groupId && it.status == 1 && it.ping >= 0 }
                            .minByOrNull { it.ping }
                        if (fallback != null && DataStore.selectedProxy == selectedAtStart) {
                            DataStore.selectedProxy = fallback.id
                            DataStore.selectedProxyManuallyChosen = false
                            Logs.w("Current node failed URL connectivity test; switching to an available node")
                            SagerNet.reloadService()
                        }
                    }
                }
                val usableCount = profiles.count { it.status == 1 && it.ping >= 0 }
                GroupManager.userInterface?.onStartupRefreshProgress(
                    "节点测速完成：${usableCount}/${profiles.size} 个可用", true
                )
            }
        } finally {
            DataStore.finishRunningTest()
        }
    }
}
