package moe.matsuri.nb4a

import android.content.Context
import io.nekohasekai.sagernet.R
import io.nekohasekai.sagernet.database.ProxyEntity.Companion.TYPE_NEKO
import io.nekohasekai.sagernet.fmt.AbstractBean
import io.nekohasekai.sagernet.ktx.app
import io.nekohasekai.sagernet.ktx.getColorAttr

// Settings for all protocols, built-in or plugin
object Protocols {

    // Deduplication

    /**
     * De-duplicate by the complete protocol configuration, not by display name
     * or server:port alone. AbstractBean equality deliberately excludes the
     * display name while retaining credentials and transport/security settings.
     */
    class Deduplication(val bean: AbstractBean) {
        override fun hashCode(): Int = bean.hashCode()

        override fun equals(other: Any?): Boolean =
            other is Deduplication && bean == other.bean
    }

    // Display

    fun Context.getProtocolColor(type: Int): Int {
        return when (type) {
            TYPE_NEKO -> getColorAttr(android.R.attr.textColorPrimary)
            else -> getColorAttr(R.attr.accentOrTextSecondary)
        }
    }

    // Test

    fun genFriendlyMsg(msg: String): String {
        val msgL = msg.lowercase()
        return when {
            msgL.contains("timeout") || msgL.contains("deadline") -> {
                app.getString(R.string.connection_test_timeout)
            }

            msgL.contains("refused") || msgL.contains("closed pipe") -> {
                app.getString(R.string.connection_test_refused)
            }

            else -> msg
        }
    }

}