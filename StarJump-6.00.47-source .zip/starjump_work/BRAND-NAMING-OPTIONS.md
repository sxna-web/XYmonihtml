# Independent brand naming – working proposal

These are creative working names, not trademark/domain clearance results. Search trademarks, app stores, domains, and package namespaces before public release.

## Recommended working name: 岚桥 / LanBridge

- Meaning: a clear bridge through changing network conditions; Chinese and English forms are pronounceable and visually compact.
- Suggested tagline: **连接有度，通行自如**
- Product descriptor: secure network connection client.
- Visual direction: a simple bridge/arc crossing two soft flowing lines; avoid shields, padlocks, flags, or imagery implying government/official affiliation.
- Tone: calm, technical, trustworthy, not overly militaristic.

## Alternatives

1. **星渡 / StarPort** – friendlier and more international; suggests a reliable gateway.
2. **澄途 / ClearRoute** – emphasizes clarity and routing; slightly more technical.
3. **云径 / CloudPath** – approachable, but more generic and likely to have naming collisions.

## Naming decision

Use **岚桥 LanBridge** as the temporary design direction only. Do not yet change the Android application ID, signing identity, repository origin, or public package name. First check trademark conflicts, domain availability, app-store name collisions, and whether a reverse-domain namespace is actually controlled by the project owner.
