#!/usr/bin/env bash
# Safely push the current branch and tags to owner-configured Git mirrors.
# No force push, no mirror deletion, no credentials embedded in URLs.
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  ./sync_git_mirrors.sh --vps-url <git-url> [--gitee-url <git-url>] [--dry-run]
  ./sync_git_mirrors.sh --gitee-url <git-url> [--dry-run]

Authentication must be configured separately (SSH agent or Git credential manager).
The script pushes only the current branch and tags. It never uses --force or --mirror.
EOF
}

vps_url=""
gitee_url=""
dry_run=0
while (($#)); do
  case "$1" in
    --vps-url) (($# >= 2)) || { usage >&2; exit 2; }; vps_url="$2"; shift 2 ;;
    --gitee-url) (($# >= 2)) || { usage >&2; exit 2; }; gitee_url="$2"; shift 2 ;;
    --dry-run) dry_run=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ -z "$vps_url" && -z "$gitee_url" ]]; then
  echo "At least one remote URL is required." >&2
  usage >&2
  exit 2
fi
command -v git >/dev/null 2>&1 || { echo "git is required." >&2; exit 1; }
git rev-parse --is-inside-work-tree >/dev/null 2>&1 || { echo "Run this script inside a Git working tree." >&2; exit 1; }
branch="$(git symbolic-ref --quiet --short HEAD || true)"
[[ -n "$branch" ]] || { echo "Detached HEAD: check out a named branch before syncing." >&2; exit 1; }

check_url() {
  local url="$1"
  # Reject embedded HTTP(S) credentials and common token query parameters.
  if [[ "$url" =~ ^https?://[^/]*:[^/@]*@ ]]; then
    echo "Refusing URL containing embedded HTTP credentials." >&2
    return 1
  fi
  if [[ "$url" =~ ([?&])(access_token|token|password|passwd|private_token)= ]]; then
    echo "Refusing URL containing a credential-like query parameter." >&2
    return 1
  fi
  [[ "$url" != *$'\n'* && "$url" != *$'\r'* ]] || { echo "Invalid newline in remote URL." >&2; return 1; }
}

sync_one() {
  local name="$1" url="$2" existing
  [[ -n "$url" ]] || return 0
  check_url "$url"
  existing="$(git remote get-url "$name" 2>/dev/null || true)"
  if [[ -n "$existing" && "$existing" != "$url" ]]; then
    echo "Remote '$name' already points elsewhere; refusing to overwrite it." >&2
    echo "Existing: $existing" >&2
    echo "Requested: $url" >&2
    return 1
  fi
  if [[ -z "$existing" ]]; then
    if ((dry_run)); then
      echo "DRY RUN: would add remote '$name' -> $url"
    else
      git remote add "$name" "$url"
      echo "Added remote '$name'."
    fi
  else
    echo "Remote '$name' is already configured."
  fi
  if ((dry_run)); then
    # Use the URL directly so a dry run never has to add or mutate a remote.
    git push --dry-run "$url" "HEAD:refs/heads/$branch"
    git push --dry-run "$url" --tags
  else
    git push "$name" "HEAD:refs/heads/$branch"
    git push "$name" --tags
  fi
}

sync_one vps "$vps_url"
sync_one gitee "$gitee_url"
echo "Sync complete for branch '$branch' and tags. No force push or remote deletion was used."
