# 6.00 source hosting, backup and recovery plan

## Destination roles

| Destination | Role | Suitable content |
|---|---|---|
| Owner-controlled VPS (Gitea recommended) | Primary private Git origin | Reviewed source history, tags, release metadata |
| Gitee private repository | Secondary source mirror | Source and tags; verify current private-repository and quota behavior before depending on it |
| Encrypted offline copy | Recovery copy | Source ZIP, checksums, deployment notes; signing keys kept separately |
| Paste.gg / paste service | Emergency text only | Non-secret recovery notes and short status text |
| QQ Favorites | Human-readable pointer | Non-secret links and recovery instructions; not a Git repository or app subscription endpoint |

Provider availability, retention, account access, limits, and privacy features can change. Do not make one provider a single point of failure.

## Operating model

1. Keep the working Git repository private and under the owner's control.
2. Push reviewed commits and version tags to the VPS origin.
3. Push reviewed commits and tags to a separately authenticated Gitee repository. Avoid destructive `git push --mirror` unless the remote is a dedicated mirror and its deletion behavior is understood.
4. At each release milestone, create a source snapshot and record its SHA-256.
5. Keep at least one offline copy on a separate device or storage medium. Encrypt it before off-site/cloud upload.
6. Perform a restore drill: download, verify checksum, extract into a new directory, and confirm required project files exist.

## Security rules

- Never place subscription URLs containing credentials, node passwords, private keys, API tokens, Android signing keystores, or production `.env` files in Paste.gg, QQ Favorites, public repositories, issue trackers, or release notes.
- Do not commit signing keys. Keep release-signing material separate, encrypted, and owner-controlled.
- Keep subscription service data separate from source code. Use TLS, server-side authorization, short-lived device-bound credentials, and signed responses.
- A private repository is access control, not a substitute for encrypted backups.
- Removing export buttons does not prevent extraction on rooted devices or through reverse engineering, runtime instrumentation, or memory inspection.

## Local snapshot utility

`backup_project.py` creates a timestamped ZIP snapshot, manifest, and SHA-256 checksum. It excludes common build caches, local Android SDK configuration, environment files, keystores, and filenames indicating secrets or credentials. It does not upload anything and does not include Git history.

Linux/macOS:

```bash
python3 backup_project.py --source /path/to/NekoBox-source --destination /path/to/backup-storage
```

Windows:

```powershell
py backup_project.py --source C:\path\to\source --destination D:\Backups
```

Review `backup-manifest.json` after each run. Skipped paths are recorded so omissions are visible. Never weaken exclusions for keys or credentials merely to make a backup appear complete.

## Restore drill

1. Verify the ZIP hash against `SHA256SUMS.txt` or `backup-manifest.json`.
2. Extract into a new empty directory; do not overwrite a working checkout.
3. Confirm `README.md`, `LICENSE`, Gradle wrapper, `app/`, and `libcore/` exist.
4. Re-fetch pinned dependencies from trusted upstream sources and build in a controlled environment.
5. Reconfigure local SDK paths and owner-controlled signing credentials outside the source archive.
6. Do not deploy a restored subscription service until TLS, authorization, signing keys, and database restore are verified.

## Not yet configured

No VPS, Gitee, Paste.gg, or QQ account is connected by this package. No remote upload or synchronization has been performed. Configure credentials locally using each provider's supported authentication method; do not paste tokens or passwords into chat.

## Owner-run VPS/Gitee synchronization helper

`sync_git_mirrors.sh` is the optional non-destructive Git push helper. It requires an existing Git working tree with a named branch and owner-configured remote URLs. It pushes only the checked-out branch and tags, supports `--dry-run`, refuses to replace a conflicting remote URL, and rejects embedded HTTP credentials. It does not use force-push or mirror deletion. See `6.00.06-GIT-MIRROR-NOTES.md`.
