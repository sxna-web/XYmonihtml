#!/usr/bin/env python3
"""Static regression checks for subscription DNS lookup lifecycle safety."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/GroupUpdater.kt").read_text()
START = SOURCE.index("protected suspend fun forceResolve(")
END = SOURCE.index("protected fun rewriteAddress(", START)
FUNCTION = SOURCE[START:END]

# DNS work must be a child of the refresh coroutine, not detached GlobalScope work.
assert "coroutineScope {" in FUNCTION
assert "launch(lookupPool)" in FUNCTION
assert "GlobalScope.launch(lookupPool)" not in FUNCTION
assert "lookupJobs.joinAll()" in FUNCTION

# The temporary executor must close even when the parent refresh is cancelled.
assert "try {" in FUNCTION
assert "finally {\n            lookupPool.close()\n        }" in FUNCTION
assert FUNCTION.index("lookupJobs.joinAll()") < FUNCTION.index("lookupPool.close()")

# Cancellation is propagated so structured concurrency can cancel sibling lookups.
assert "catch (e: CancellationException)" in FUNCTION
assert "throw e" in FUNCTION

print("PASS: DNS lookups are structured children of the subscription refresh")
print("PASS: cancellation propagates and the temporary DNS executor closes in finally")
