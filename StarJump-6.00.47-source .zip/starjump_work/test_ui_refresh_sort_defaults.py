from pathlib import Path
ROOT = Path(__file__).resolve().parent
menu = (ROOT / 'app/src/main/res/menu/add_profile_menu.xml').read_text()
proxy_group = (ROOT / 'app/src/main/java/io/nekohasekai/sagernet/database/ProxyGroup.kt').read_text()
data_store = (ROOT / 'app/src/main/java/io/nekohasekai/sagernet/database/DataStore.kt').read_text()
prefs = (ROOT / 'app/src/main/res/xml/group_preferences.xml').read_text()
fragment = (ROOT / 'app/src/main/java/io/nekohasekai/sagernet/ui/ConfigurationFragment.kt').read_text()
assert menu.count('android:id="@+id/action_update_subscription"') == 1
assert 'android:icon="@drawable/ic_baseline_refresh_24"' in menu
assert 'app:showAsAction="always"' in menu
assert 'var order: Int = GroupOrder.BY_DELAY' in proxy_group
assert 'stringToInt(Key.GROUP_ORDER) { GroupOrder.BY_DELAY }' in data_store
assert 'app:defaultValue="2"' in prefs
assert 'GroupOrder.BY_DELAY' in fragment and 'it.ping' in fragment
assert 'GroupUpdater.startUpdate(group, true)' in fragment
print('PASS: subscription refresh is a dedicated toolbar action using the existing updater')
print('PASS: new groups and group settings default to delay sorting')
print('PASS: node lists sort by measured delay when delay order is selected')

# Both endpoints are independently editable in the subscription settings UI.
assert 'app:key="subscriptionLink"' in prefs
assert 'app:key="subscriptionBackupLink"' in prefs
print('PASS: primary and backup subscription URL fields are present in group settings')
