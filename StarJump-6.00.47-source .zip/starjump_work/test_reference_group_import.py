#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
HELPER = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/ReferenceSubscription.kt").read_text()
STARTUP = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/bg/AutoNodeStartup.kt").read_text()
RAW = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/RawUpdater.kt").read_text()
LAYOUT = ROOT / "app/src/main/res/layout/layout_group_item.xml"
ICON = ROOT / "app/src/main/res/drawable/ic_baseline_add_40.xml"

assert "ensureGroups()" in HELPER
assert "星跃节点 01" in HELPER and "星跃节点 02" in HELPER
assert "星跃节点 03" in HELPER and "星跃节点 04" in HELPER and "星跃节点 05" in HELPER
assert "LEGACY_RAW_URL" in HELPER
assert "existing.name = slot.name" in HELPER
assert "GroupManager.createGroup(" in HELPER
assert "SagerDatabase.groupDao.updateGroup(existing)" in HELPER
assert "DataStore.selectedGroup = result.first().id" in HELPER
assert "ReferenceSubscription.ensureGroups()" in STARTUP
assert "referenceGroups.filter" in STARTUP
assert "ReferenceSubscription.sourceUrlFor(it)" in STARTUP
assert "proxyGroup.isStarJumpReservedGroup()" in RAW
assert "ReferenceSubscription.sourceUrlFor(proxyGroup)" in RAW
assert "PASTE_GG_URL_SLOT_02" in HELPER
assert "PASTE_GG_URL_SLOT_03" in HELPER
assert "PASTE_GG_URL_SLOT_04" in HELPER
assert "PASTE_GG_URL_SLOT_05" in HELPER
assert "link = """ in HELPER
assert "starJumpBuiltIn = true" in HELPER
assert "parseRaw(parseText)" in RAW
ET.parse(LAYOUT)
ET.parse(ICON)
layout = LAYOUT.read_text()
block = layout.split('android:id="@+id/options"', 1)[1].split('/>', 1)[0]
assert 'android:layout_width="56dp"' in block
assert 'android:layout_height="56dp"' in block
assert '@drawable/ic_baseline_add_40' in block
assert 'android:tint="#000000"' in ICON.read_text()
print("PASS: five independent built-in groups are created idempotently and legacy data is migrated")
print("PASS: each configured slot uses the standard parser; empty slots are skipped")
print("PASS: rightmost group-card action uses the larger black plus icon")
