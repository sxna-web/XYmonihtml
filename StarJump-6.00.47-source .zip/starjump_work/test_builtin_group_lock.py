from pathlib import Path

ROOT = Path(__file__).parent
proxy_group = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/database/ProxyGroup.kt").read_text()
group_fragment = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/ui/GroupFragment.kt").read_text()
settings = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/ui/GroupSettingsActivity.kt").read_text()
manager = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/database/GroupManager.kt").read_text()

checks = {
    "built-in identity uses dedicated database flag with legacy migration fallback": "if (starJumpBuiltIn) return true" in proxy_group and "link == STARJUMP_BUILTIN_LINK || link == STARJUMP_LEGACY_LINK" in proxy_group,
    "built-in group export is rejected": 'check(!isStarJumpReservedGroup()) { "Built-in groups cannot be exported" }' in proxy_group,
    "built-in edit button is hidden": "editButton.isGone = proxyGroup.ungrouped || proxyGroup.isStarJumpReservedGroup()" in group_fragment,
    "built-in overflow/action button is hidden": "optionsButton.isGone = proxyGroup.isStarJumpReservedGroup()" in group_fragment,
    "built-in group cannot be swiped or reordered": group_fragment.count("proxyGroup.isStarJumpReservedGroup() || proxyGroup.id in GroupUpdater.updating") >= 2,
    "direct settings launch is blocked": "if (entity.isStarJumpReservedGroup())" in settings and "不支持查看或修改设置" in settings,
    "clear and single-group deletion are blocked": manager.count("getById(groupId)?.isStarJumpReservedGroup() == true) return") >= 2,
    "bulk deletion filters built-in groups": "group.filterNot { it.isStarJumpReservedGroup() }" in manager,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if not all(checks.values()):
    raise SystemExit(1)
