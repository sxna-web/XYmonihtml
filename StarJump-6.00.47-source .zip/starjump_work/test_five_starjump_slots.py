#!/usr/bin/env python3
"""Regression checks for the five independent StarJump Paste.gg slots."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
helper = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/ReferenceSubscription.kt").read_text()
startup = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/bg/AutoNodeStartup.kt").read_text()
raw = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/RawUpdater.kt").read_text()
ui = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/ui/GroupFragment.kt").read_text()

# Five stable independent group identities and five source slots.
for n in range(1, 6):
    assert f'"星跃节点 {n:02d}"' in helper
    assert f'SLOT_{n:02d}_URL' in helper
assert helper.count('Slot(') >= 5
assert 'SLOT_01_URL' in helper and 'paste.gg/p/xh/e08d0acaa7af4e7ca654cd938e0ba623' in helper
for n in range(2, 6):
    assert f'PASTE_GG_URL_SLOT_{n:02d}' in helper

# Legacy single group is migrated in place, preserving its DB identity and nodes.
assert 'reserved.firstOrNull { it.name == "星跃节点" }' in helper
assert 'val usedGroupIds = HashSet<Long>()' in helper
assert 'candidate?.takeIf { usedGroupIds.add(it.id) }' in helper
assert 'existing.name = slot.name' in helper
assert 'SagerDatabase.groupDao.updateGroup(existing)' in helper
assert 'existing.starJumpBuiltIn = true' in helper
assert 'if (createdFirst) {' in helper

# Missing slots are created separately; each is independently addressable by group ID.
assert 'for (slot in slots)' in helper
assert 'GroupManager.createGroup(' in helper
assert 'result += group' in helper
assert 'starJumpBuiltIn = true' in helper

# Startup processes every configured slot independently; empty placeholders are skipped.
assert 'ReferenceSubscription.ensureGroups()' in startup
assert 'referenceGroups.filter' in startup
assert '!ReferenceSubscription.sourceUrlFor(it).isNullOrBlank()' in startup
assert 'for (subscriptionGroup in configuredSubscriptions)' in startup
assert 'GroupUpdater.executeUpdateIfIdle(subscriptionGroup, false)' in startup
assert 'catch (e: Exception)' in startup

# Each reserved group routes only to its own configured source, never another slot's DB URL.
assert 'ReferenceSubscription.sourceUrlFor(proxyGroup)' in raw
assert 'listOfNotNull(ReferenceSubscription.sourceUrlFor(proxyGroup))' in raw
assert 'listOf(subscription.link, subscription.backupLink)' in raw
assert 'parseRaw(parseText)' in raw
assert raw.index('if (proxies.isEmpty())') < raw.index('SagerDatabase.instance.withTransaction')

# Empty slots do not present a nonfunctional manual refresh action.
assert 'ReferenceSubscription.sourceUrlFor(proxyGroup).isNullOrBlank()' in ui

print('PASS: five named groups and five independent APK source slots exist')
print('PASS: old single group is renamed to 01 in place')
print('PASS: slots 02-05 remain explicit replaceable placeholders')
print('PASS: startup updates every configured slot independently and skips blank slots')
print('PASS: each group fetches only its own source through the standard parser')
print('PASS: empty or invalid downloads fail before database writes, preserving old nodes')
print('PASS: unconfigured slots do not show a misleading manual refresh action')
