#!/usr/bin/env python3
"""Static regression checks for startup refresh/test/failover safety."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MAIN = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/ui/MainActivity.kt").read_text()
STORE = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/database/DataStore.kt").read_text()
STARTUP = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/bg/AutoNodeStartup.kt").read_text()
MANUAL = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/ui/ConfigurationFragment.kt").read_text()

# Automatic and manual tests use one atomic compare-and-set gate.
assert "AtomicBoolean(false)" in STORE
assert "compareAndSet(false, true)" in STORE
assert "fun finishRunningTest()" in STORE
assert "while (!gateAcquired && gateAttempts < 60)" in STARTUP
assert "if (!gateAcquired) delay(500)" in STARTUP
assert "其他测速任务仍在进行，请稍后手动刷新" in STARTUP
assert MANUAL.count("if (!DataStore.tryStartRunningTest()) return") == 2
assert "lifecycleScope.launch {" in MAIN
assert "lifecycleScope.launch(Dispatchers.IO)" not in MAIN
assert STARTUP.index("DataStore.tryStartRunningTest()") < STARTUP.index("withContext(Dispatchers.IO)")


# A startup refresh claims a subscription only when no other refresh owns it;
# it must not call the duplicate-cancelling manual API.
UPDATER = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/GroupUpdater.kt").read_text()
assert "suspend fun executeUpdateIfIdle(proxyGroup: ProxyGroup, byUser: Boolean): Boolean" in UPDATER
assert "if (!updating.add(proxyGroup.id)) return false" in UPDATER
assert "GroupUpdater.executeUpdateIfIdle(subscriptionGroup, false)" in STARTUP
assert "GroupUpdater.executeUpdate(subscriptionGroup, false)" not in STARTUP

# Ensure the dedicated reference group exists before resolving the selected group;
# refresh only that group and do not overwrite unrelated subscriptions.
assert "ReferenceSubscription.ensureGroups()" in STARTUP
assert "val configuredSubscriptions = referenceGroups.filter" in STARTUP
assert "ReferenceSubscription.sourceUrlFor(it)" in STARTUP
assert "for (subscriptionGroup in configuredSubscriptions)" in STARTUP
assert "GroupUpdater.executeUpdateIfIdle(subscriptionGroup, false)" in STARTUP
assert "Startup subscription refresh already running" in STARTUP
assert "正在更新星跃节点" in STARTUP
assert "星跃节点更新完成" in STARTUP
assert "onStartupRefreshProgress" in STARTUP
assert "mayUpdate" not in STARTUP
assert STARTUP.index("GroupUpdater.executeUpdateIfIdle(subscriptionGroup, false)") < STARTUP.index("SagerDatabase.proxyDao.getByGroup(groupId)")
assert "Automatic subscription refresh failed" in STARTUP

# A -1 URL result is failed in both automatic and manual tests.
assert "profile.status = if (profile.ping >= 0) 1 else 3" in STARTUP
assert "profile.status = if (result >= 0) 1 else 3" in MANUAL
assert 'if (result < 0) profile.error = "URL 连通性测试失败"' in MANUAL

# A manual selection is respected; failover only reloads an already-running service.
assert "if (selectedAtStart != 0L && selectedAfterTest == selectedAtStart" in STARTUP
assert ".filter { it.id != selectedAtStart" in STARTUP
assert "it.status == 1 && it.ping >= 0" in STARTUP
assert "if (fallback != null && DataStore.selectedProxy == selectedAtStart)" in STARTUP
assert "DataStore.serviceState.started" in STARTUP
assert "SagerNet.reloadService()" in STARTUP
assert "SagerNet.startService()" not in STARTUP

print("PASS: startup waits briefly for the shared atomic test gate instead of silently skipping")
print("PASS: startup subscription refresh never cancels an already-running user refresh")
print("PASS: duplicate subscription refreshes are rejected with an atomic non-cancelling claim")
print("PASS: five dedicated groups are created/reused; only configured source slots refresh and unrelated groups are not overwritten")
print("PASS: startup subscription progress is surfaced to the user")
print("PASS: URL test -1 is failed in both manual and automatic test paths")
print("PASS: manual selection is respected; failover reloads only an already-started service")

assert "Startup subscription refresh returned failure" in STARTUP
assert "星跃节点更新失败" in STARTUP
print("PASS: failed slot refreshes are counted independently and saved nodes remain the fallback")
assert MANUAL.count('val cleanupStarted = AtomicBoolean(false)') == 2
assert MANUAL.count('cleanupStarted.compareAndSet(false, true)') == 2
print('PASS: manual TCP/URL test cleanup is idempotent and releases the shared gate once')

# Automatic selection must never fall back to a failed node when every URL test fails.
assert "val firstUsableNode = profiles" in STARTUP
assert ".filter { it.groupId == groupId && it.status == 1 && it.ping >= 0 }" in STARTUP
assert "No usable node was confirmed; keeping the existing node selection" in STARTUP
assert "sortedBy { if (it.status == 1 && it.ping >= 0) it.ping else Int.MAX_VALUE }" not in STARTUP
assert "selectedProfile.groupId == groupId" in STARTUP
print("PASS: all-failed startup tests preserve the existing selection instead of choosing a failed node")
