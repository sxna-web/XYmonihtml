#!/usr/bin/env python3
"""Integration tests for the offline-root emergency subscription recovery envelope."""
import base64
import hashlib
import json
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SIGNER = ROOT / "create_signed_subscription.py"
OPENSSL = shutil.which("openssl")


def run(args):
    result = subprocess.run(args, capture_output=True, text=True)
    if result.returncode:
        raise AssertionError(f"Command failed: {' '.join(map(str, args))}\n{result.stderr}")
    return result


def main():
    if not OPENSSL:
        raise SystemExit("OpenSSL is required")
    with tempfile.TemporaryDirectory(prefix="nbx-recovery-test-") as td:
        d = Path(td)
        old_key, recovery_key, new_key = d / "old.pem", d / "recovery.pem", d / "new.pem"
        payload, output = d / "nodes.txt", d / "recovery.json"
        for key in (old_key, recovery_key, new_key):
            run([OPENSSL, "genpkey", "-algorithm", "RSA", "-pkeyopt", "rsa_keygen_bits:3072", "-out", str(key)])
        payload.write_text("vless://example.invalid:443#test\n", encoding="utf-8")
        run(["python3", str(SIGNER), "--private-key", str(new_key), "--recovery-private-key", str(recovery_key),
             "--input", str(payload), "--output", str(output), "--version", "100"])
        env = json.loads(output.read_text(encoding="utf-8"))
        assert "key_recovery" in env and "key_rotation" not in env
        new_pub = d / "new-public.der"
        recovery_pub = d / "recovery-public.der"
        run([OPENSSL, "pkey", "-in", str(new_key), "-pubout", "-outform", "DER", "-out", str(new_pub)])
        run([OPENSSL, "pkey", "-in", str(recovery_key), "-pubout", "-outform", "DER", "-out", str(recovery_pub)])
        new_der = new_pub.read_bytes()
        recovery_der = recovery_pub.read_bytes()
        assert base64.b64decode(env["key_recovery"]["new_public_key"]) == new_der

        issued, expires, version = env["issued_at"], env["expires_at"], env["version"]
        payload_bytes = base64.b64decode(env["payload"])
        digest = hashlib.sha256(payload_bytes).hexdigest()
        fingerprint = hashlib.sha256(new_der).hexdigest()
        recovery_message = (f"nbx-key-recovery-v1\n{fingerprint}\n{version}\n{issued}\n{expires}\n{digest}").encode()
        msg, sig, pub = d / "message.bin", d / "sig.bin", d / "recovery-pub.der"
        msg.write_bytes(recovery_message)
        sig.write_bytes(base64.b64decode(env["key_recovery"]["signature"]))
        pub.write_bytes(recovery_der)
        run([OPENSSL, "dgst", "-sha256", "-verify", str(pub), "-keyform", "DER", "-signature", str(sig), str(msg)])

        # Altering payload bytes while retaining the old root signature must fail.
        tampered = payload_bytes + b"#tampered"
        tampered_digest = hashlib.sha256(tampered).hexdigest()
        bad_message = (f"nbx-key-recovery-v1\n{fingerprint}\n{version}\n{issued}\n{expires}\n{tampered_digest}").encode()
        msg.write_bytes(bad_message)
        bad = subprocess.run([OPENSSL, "dgst", "-sha256", "-verify", str(pub), "-keyform", "DER", "-signature", str(sig), str(msg)], capture_output=True, text=True)
        assert bad.returncode != 0, "tampered payload unexpectedly passed recovery signature verification"

        # The envelope's ordinary subscription signature must be made by the replacement online key.
        signed_message = f"nbx-subscription-v1\n{version}\n{issued}\n{expires}\n{digest}".encode()
        msg.write_bytes(signed_message)
        env_sig = d / "envelope.sig"
        env_sig.write_bytes(base64.b64decode(env["signature"]))
        new_pub_path = d / "new-pub.der"
        new_pub_path.write_bytes(new_der)
        run([OPENSSL, "dgst", "-sha256", "-verify", str(new_pub_path), "-keyform", "DER", "-signature", str(env_sig), str(msg)])

        print("PASS: offline recovery signature validates")
        print("PASS: altered payload is rejected by recovery authorization")
        print("PASS: recovered subscription envelope is signed by the replacement online key")
        print("PASS: recovery private key is not present in the envelope")


if __name__ == "__main__":
    main()
