from pathlib import Path
ROOT = Path(__file__).resolve().parent
config = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/ui/ConfigurationFragment.kt").read_text()
menu = (ROOT / "app/src/main/res/menu/add_profile_menu.xml").read_text()
proxy = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/database/ProxyEntity.kt").read_text()
group_ui = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/ui/GroupFragment.kt").read_text()
zh_cn = (ROOT / "app/src/main/res/values-zh-rCN/strings.xml").read_text()
zh_tw = (ROOT / "app/src/main/res/values-zh-rTW/strings.xml").read_text()
# First built-in slot stays visible; other empty groups are filtered from main tabs.
assert 'group.isStarJumpReservedGroup() && group.name == "星跃节点 01"' in config
assert 'SagerDatabase.proxyDao.countByGroup(group.id) > 0L' in config
assert 'if (!isFirstStarJumpSlot && SagerDatabase.proxyDao.countByGroup(group.id) == 0L) return' in config
# Empty groups are hidden from the group manager, not deleted from Room.
assert 'groups.removeAll { group ->' in group_ui
assert 'SagerDatabase.proxyDao.countByGroup(group.id) == 0L' in group_ui
# Last valid selection is preserved; invalid/hidden selection falls back to slot 01.
assert 'DataStore.currentGroupId()' in config
assert 'selectedGroupIndex < 0' in config
# Region label and StarJump display path are present.
assert 'fun starJumpDisplayName()' in proxy
assert '星跃节点 $ordinal' in proxy
# Manual protocol entries are now direct children of the add-profile popup, not a nested manual-settings submenu.
assert 'add_profile_methods_manual_settings' not in menu
assert 'starjump_connection_success' in config
assert '端口连通性测试' in zh_cn and '网络连通性测试' in zh_cn
assert '連接埠連通性測試' in zh_tw and '網路連通性測試' in zh_tw
for item in ['action_new_socks','action_new_vmess','action_new_vless','action_new_trojan','action_new_wg']:
    assert f'@+id/{item}' in menu
print('PASS: first StarJump slot and remembered group selection are handled')
print('PASS: empty groups are hidden in main tabs and group manager without deleting records')
print('PASS: StarJump region labels are wired into the node display path')
print('PASS: manual protocol choices are moved out of the nested submenu')
print('PASS: real URL connectivity test and TCP port test labels/results are localized in Chinese')

# Empty newly-created groups stay hidden until they contain nodes; successful
# update completion triggers groupUpdated/reload and then reveals populated groups.
group_fragment = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/ui/GroupFragment.kt").read_text()
profile_manager = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/database/ProfileManager.kt").read_text()
profile_settings = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/ui/profile/ProfileSettingsActivity.kt").read_text()
updater = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/GroupUpdater.kt").read_text()
raw_updater = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/RawUpdater.kt").read_text()
assert 'val shouldShow = isFirstStarJumpSlot ||' in group_fragment
assert 'if (group.type == GroupType.SUBSCRIPTION) {\n                GroupUpdater.startUpdate(group, true)' in group_fragment
assert 'SagerDatabase.groupDao.getById(groupId)?.isStarJumpReservedGroup() == true) return' in profile_manager
assert '星跃内置节点仅供使用，不支持编辑' in profile_settings
assert 'StarJump node DNS lookup failed' in updater
assert 'Updated StarJump node' in raw_updater and 'Inserted StarJump node' in raw_updater
print('PASS: empty new groups remain hidden until populated')
print('PASS: direct editor and central deletion paths reject built-in nodes')
print('PASS: built-in DNS/update logs do not expose raw node names or server addresses')

# Launcher foreground uses Android adaptive-icon 108dp canvases at each density.
from PIL import Image
expected_foreground = {"mdpi": 108, "hdpi": 162, "xhdpi": 216, "xxhdpi": 324, "xxxhdpi": 432}
for density, size in expected_foreground.items():
    image = Image.open(ROOT / f"app/src/main/res/mipmap-{density}/ic_launcher_foreground.png").convert("RGBA")
    assert image.size == (size, size), (density, image.size)
    assert image.getchannel("A").getbbox() is not None
print('PASS: adaptive launcher foregrounds use correct Android density dimensions and visible artwork')
