# 星跃 6.00.20：启动自动获取、真实测速与失效切换

## 本轮行为
- MainActivity 首次进入前台时触发一次启动流程；同一 Activity 实例不会在每次 onStart 重复触发。
- 若当前组是订阅组，且订阅设置允许当前网络状态下更新，则先尝试刷新订阅；刷新失败时保留并测试上次已保存的节点列表。
- 订阅刷新后重新读取当前组节点，再逐个调用项目已有 `UrlTest` / sing-box URL 请求测试路径；不是 TCP 端口 ping。
- 使用现有并发设置（限制 1..10）；保存 ping、status、error 并通知节点列表刷新。
- `Libcore.urlTest` 返回 -1（未抛异常）也明确记为失败，不能误标记成可用节点。
- 若测试开始时已连接，且原选中节点仍然是当前选中节点、真实 URL 测试失败，则从同组成功节点中选择延迟最低者，更新选择并请求服务重载。
- 若测速期间用户手动切换了节点，不会覆盖用户选择。
- 启动自动测试与手动测速共享 `DataStore.runningTest`，避免两组测试同时运行。

## 修改文件
- `app/src/main/java/io/nekohasekai/sagernet/bg/AutoNodeStartup.kt`
- `app/src/main/java/io/nekohasekai/sagernet/ui/MainActivity.kt`
- 备份：`MainActivity.kt.bak-before-auto-startup`、`AutoNodeStartup.kt.bak-before-ping-failover-fix`

## 验证状态
- 已检查 `UrlTest` 的实现：它调用 `TestInstance` 和 `Libcore.urlTest`，为 URL 连通性测试，不是 TCP ping。
- 已检查 `Libcore.urlTest` 的结果处理：返回 -1 时本轮已修正为失败状态，并可进入失效节点切换判断。
- 6.00.21 补充修复：自动测速入口改为主线程先占用共享测试标记，再切换 IO 执行；`DataStore.runningTest` 增加 `@Volatile`，降低自动测速与手动测速并发启动风险。
- 新增 `test_auto_node_startup_audit.py`，覆盖启动门闩、订阅刷新顺序、真实 URL 失败判定、手动选择保护及不擅自启动服务。
- Gradle 编译：未完成。Gradle 8.10.2 wrapper 因环境无法解析 `services.gradle.org`（`UnknownHostException`）而无法下载发行包；这不是 Kotlin 编译诊断。
- APK 构建、安装及真机网络测试：未完成。自动重连仍需真机验证，尤其是运行中服务收到 reload 广播后的实际行为。
