plugins {
id("com.google.devtools.ksp") version "2.0.21-1.0.27" apply false
}

// Top-level build file
allprojects {
apply(from = "${rootProject.projectDir}/repositories.gradle.kts")
}

tasks.register<Delete>("clean") {
delete(rootProject.buildDir)
}