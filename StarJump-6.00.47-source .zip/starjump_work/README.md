# NekoBox for Android

[![API](https://img.shields.io/badge/API-21%2B-brightgreen.svg?style=flat)](https://android-arsenal.com/api?level=21)
[![Releases](https://img.shields.io/github/v/release/KanadeAlice/NekoBoxForAndroid-kanade)](https://github.com/KanadeAlice/NekoBoxForAndroid-kanade/releases)
[![License: GPL-3.0](https://img.shields.io/badge/license-GPL--3.0-orange.svg)](https://www.gnu.org/licenses/gpl-3.0)

sing-box / universal proxy toolchain for Android.

一款使用 sing-box 的 Android 通用代理软件.

> **本仓库是 [MatsuriDayo/NekoBoxForAndroid](https://github.com/MatsuriDayo/NekoBoxForAndroid) 的个人分支 (fork)。** 在其 v1.4.2 基础上把内核升级到 sing-box 1.14 并做了相应适配 (DNS / TUN / WireGuard schema、REALITY)。版权与商标归上游所有，本分支仅供个人使用。
>
> **This is a personal fork of [MatsuriDayo/NekoBoxForAndroid](https://github.com/MatsuriDayo/NekoBoxForAndroid)**, with the kernel upgraded to sing-box 1.14. All rights and trademarks belong to the upstream project.

## Project milestone 6.00.10

This source snapshot adds an independently pinned offline recovery public key for emergency replacement of a compromised online subscription-signing key. See `6.00.10-OFFLINE-RECOVERY-NOTES.md` for enrollment and recovery steps, and `BRAND-NAMING-OPTIONS.md` for provisional independent branding. The proposed working brand is **岚桥 / LanBridge**; trademark, domain, and package-namespace clearance are not yet performed.

## 下载 / Downloads

[![GitHub All Releases](https://img.shields.io/github/downloads/KanadeAlice/NekoBoxForAndroid-kanade/total?label=downloads-total&logo=github&style=flat-square)](https://github.com/KanadeAlice/NekoBoxForAndroid-kanade/releases)

[GitHub Releases 下载](https://github.com/KanadeAlice/NekoBoxForAndroid-kanade/releases)

**Google Play 版本自 2024 年 5 月起已被第三方控制，为非开源版本，请不要下载。**

**The Google Play version has been controlled by a third party since May 2024 and is a non-open
source version. Please do not download it.**

## 更新日志 & Telegram 发布频道 / Changelog & Telegram Channel

https://t.me/Matsuridayo

## 项目主页 & 文档 / Homepage & Documents

https://matsuridayo.github.io

## 支持的代理协议 / Supported Proxy Protocols

* SOCKS (4/4a/5)
* HTTP(S)
* SSH
* Shadowsocks
* VMess
* Trojan
* VLESS
* AnyTLS
* ShadowTLS
* TUIC
* Hysteria 1/2
* WireGuard
* Trojan-Go (trojan-go-plugin)
* NaïveProxy (naive-plugin)
* Mieru (mieru-plugin)

请到[这里](https://matsuridayo.github.io/nb4a-plugin/)下载插件以获得完整的代理支持.

Please visit [here](https://matsuridayo.github.io/nb4a-plugin/) to download plugins for full proxy
supports.

## 支持的订阅格式 / Supported Subscription Format

* 一些广泛使用的格式 (如 Shadowsocks, ClashMeta 和 v2rayN)
* sing-box 出站

仅支持解析出站，即节点。分流规则等信息会被忽略。

* Some widely used formats (like Shadowsocks, ClashMeta and v2rayN)
* sing-box outbound

Only resolving outbound, i.e. nodes, is supported. Information such as diversion rules are ignored.

## Credits

Upstream / 上游:

- [MatsuriDayo/NekoBoxForAndroid](https://github.com/MatsuriDayo/NekoBoxForAndroid)

Core:

- [SagerNet/sing-box](https://github.com/SagerNet/sing-box)

Android GUI:

- [shadowsocks/shadowsocks-android](https://github.com/shadowsocks/shadowsocks-android)
- [SagerNet/SagerNet](https://github.com/SagerNet/SagerNet)

Web Dashboard:

- [Yacd-meta](https://github.com/MetaCubeX/Yacd-meta)

## 6.00 backup and recovery utilities

- `backup_project.py`: local source ZIP + manifest + SHA-256.
- `encrypt_backup_gpg.py`: optional GPG AES-256 encryption (interactive passphrase prompt).
- `restore_project.py`: checksum-verified, path-safe restore into a new/empty directory.

See `BACKUP-RECOVERY-PLAN.md` and `6.00.05-ENCRYPTION-RESTORE-NOTES.md`. These utilities do not upload data to remote services.

## Safe remote Git mirrors

`sync_git_mirrors.sh` can push the current branch and tags to owner-configured VPS and Gitee remotes. It refuses embedded HTTPS credentials, refuses to replace a different existing remote, and never force-pushes or deletes remote refs. See `6.00.06-GIT-MIRROR-NOTES.md`.

## Subscription endpoint failover

Each subscription can optionally set a secondary URL. The client tries the primary first, then the secondary only if download/parse/basic node validation fails. Existing nodes are applied only after a successful validated parse and Room transaction. The backup URL is not included in share serialization. See `6.00.07-SUBSCRIPTION-FAILOVER-NOTES.md`.

## Signed subscriptions (6.00.08)

Subscriptions can optionally pin a Base64 X.509 RSA public key. Once configured, unsigned responses are rejected and the client validates a signed `nbx-subscription-v1` envelope, expiry, and monotonic version before parsing nodes. Existing feeds remain compatible while the key field is blank. See `6.00.08-SIGNED-SUBSCRIPTION-NOTES.md` for the exact signing format and safe key setup. The matching private key must remain on infrastructure controlled by the subscription owner and must never be committed to this repository.

## Signed subscription key rotation (6.00.09)

The signed-subscription envelope optionally supports cross-signed RSA public-key rotation. A replacement key is accepted only when the currently pinned key authorizes its SHA-256 fingerprint; the app persists the new pin only after the subscription update passes validation. See `6.00.09-KEY-ROTATION-REVOCATION-NOTES.md` for the operator procedure and emergency-revocation limitations. This is planned rotation, not a complete PKI or compromise-recovery system.

## Android compatibility preflight (6.00.11)

Run `python3 check_android_build_env.py` for a read-only local toolchain and SDK audit. The current source is configured for minSdk 21, compileSdk 35, and targetSdk 35; API 36 is not yet enabled. See `6.00.11-ANDROID-COMPATIBILITY-AUDIT.md` and fill `6.00.11-DEVICE-MATRIX.csv` with physical-device results. A preflight report is not a successful APK build or device certification.

## 6.00.12 subscription parser hardening

6.00.12 makes malformed Clash VMess/VLESS/Trojan entries and malformed WireGuard peers fail the complete subscription candidate instead of silently accepting a partial node list. See `6.00.12-SUBSCRIPTION-INTEGRATION-AUDIT.md` and run `python3 test_subscription_integration_audit.py` for source-level regression checks.


## 6.00.13 WireGuard validation hardening

6.00.13 rejects blank WireGuard interface private keys, blank peer public keys, empty interface addresses, and endpoint ports outside 1–65535. Interface address fragments are trimmed. See `6.00.13-WIREGUARD-VALIDATION-AUDIT.md`; source-level checks are available through `python3 test_subscription_integration_audit.py`.
