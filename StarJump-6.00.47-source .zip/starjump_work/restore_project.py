#!/usr/bin/env python3
"""Verify and safely restore a source snapshot created by backup_project.py."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import zipfile

REQUIRED = (
    "README.md",
    "LICENSE",
    "gradlew",
    "app/build.gradle.kts",
    "libcore/go.mod",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_member_name(name: str) -> PurePosixPath:
    # ZIP names use forward slashes. Reject absolute paths, drive prefixes,
    # parent traversal, empty paths and backslashes (ambiguous on Windows).
    if not name or "\\" in name or name.startswith("/"):
        raise ValueError(f"unsafe archive path: {name!r}")
    path = PurePosixPath(name)
    if path.is_absolute() or any(part in ("", ".", "..") for part in path.parts):
        raise ValueError(f"unsafe archive path: {name!r}")
    if path.parts and ":" in path.parts[0]:
        raise ValueError(f"drive-qualified archive path: {name!r}")
    return path


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify and safely restore a source snapshot.")
    parser.add_argument("--archive", required=True, help="source-snapshot.zip")
    parser.add_argument("--manifest", required=True, help="backup-manifest.json")
    parser.add_argument("--destination", required=True, help="new, empty destination directory")
    args = parser.parse_args()

    archive = Path(args.archive).expanduser().resolve()
    manifest_path = Path(args.manifest).expanduser().resolve()
    destination = Path(args.destination).expanduser().resolve()
    if not archive.is_file() or not manifest_path.is_file():
        parser.error("archive and manifest must both exist")
    if destination.exists() and (not destination.is_dir() or any(destination.iterdir())):
        parser.error("destination must not exist or must be an empty directory")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    expected_hash = manifest.get("archive_sha256")
    if not isinstance(expected_hash, str) or len(expected_hash) != 64:
        raise SystemExit("Invalid manifest: archive_sha256 is missing or malformed")
    actual_hash = sha256(archive)
    if actual_hash.lower() != expected_hash.lower():
        raise SystemExit(f"SHA-256 mismatch; expected {expected_hash}, got {actual_hash}")

    destination.mkdir(parents=True, exist_ok=True)
    seen: set[str] = set()
    extracted: list[str] = []
    try:
        with zipfile.ZipFile(archive, "r") as zipped:
            infos = zipped.infolist()
            if len(infos) > 100_000:
                raise ValueError("archive contains too many entries")
            for info in infos:
                rel = safe_member_name(info.filename.rstrip("/"))
                normalized = rel.as_posix()
                if normalized in seen:
                    raise ValueError(f"duplicate archive path: {normalized}")
                seen.add(normalized)
                mode = (info.external_attr >> 16) & 0xFFFF
                if stat.S_ISLNK(mode):
                    raise ValueError(f"symbolic links are not restored: {normalized}")
                target = destination.joinpath(*rel.parts)
                # Resolve the parent to guard against path traversal.
                if destination not in target.resolve().parents and target.resolve() != destination:
                    raise ValueError(f"archive path escapes destination: {normalized}")
                if info.is_dir() or info.filename.endswith("/"):
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with zipped.open(info, "r") as source, target.open("xb") as output:
                    while True:
                        chunk = source.read(1024 * 1024)
                        if not chunk:
                            break
                        output.write(chunk)
                extracted.append(normalized)

        missing = [item for item in REQUIRED if not (destination / item).is_file()]
        if missing:
            raise ValueError("restore is missing required project files: " + ", ".join(missing))
        declared_count = manifest.get("included_file_count")
        if isinstance(declared_count, int) and declared_count != len(extracted):
            raise ValueError(
                f"manifest file count mismatch: expected {declared_count}, restored {len(extracted)}"
            )
    except Exception:
        # Never leave a partial tree that could be mistaken for a successful restore.
        import shutil
        shutil.rmtree(destination, ignore_errors=True)
        raise

    print(f"Restore verified: {destination}")
    print(f"SHA-256: {actual_hash}")
    print(f"Files restored: {len(extracted)}")
    print("Required project structure: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
