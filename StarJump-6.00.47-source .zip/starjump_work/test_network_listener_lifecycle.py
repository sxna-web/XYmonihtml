#!/usr/bin/env python3
"""Static regression checks for default-network callback lifecycle safety."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/utils/DefaultNetworkListener.kt").read_text()
MANUAL = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/ui/ConfigurationFragment.kt").read_text()
STARTUP = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/bg/AutoNodeStartup.kt").read_text()

assert "private var registered = false" in SOURCE
assert "registered = true" in SOURCE
assert "registered = false" in SOURCE
assert "if (!registered) return" in SOURCE
assert "catch (e: IllegalArgumentException)" in SOURCE
assert "Unable to unregister default network callback" in SOURCE
assert SOURCE.index("if (!registered) return") < SOURCE.index("unregisterNetworkCallback(Callback)")

# Both manual test flows must release the shared gate even if reloading UI state fails.
assert MANUAL.count("finally {\n                        DataStore.finishRunningTest()\n                    }") == 2
assert MANUAL.count("GroupManager.postReload(group.id)") == 2
assert STARTUP.count('profile.error = "URL 连通性测试失败"') == 1

# If the last listener stops while get() is waiting, fail pending requests
# instead of leaving their coroutines suspended indefinitely.
assert 'pendingRequests.forEach { request ->' in SOURCE
assert 'request.response.completeExceptionally(' in SOURCE
assert 'Network listener stopped before a network became available' in SOURCE
assert 'pendingRequests.clear()' in SOURCE
assert SOURCE.index('request.response.completeExceptionally(') < SOURCE.index('unregister()')

print("PASS: fallback mode never unregisters a callback that was not registered")
print("PASS: callback teardown exceptions cannot escape and terminate the actor")
print("PASS: pending get() calls fail promptly when the last listener stops")
print("PASS: manual TCP/URL test cleanup releases the shared gate in finally")
print("PASS: automatic URL-test failure message is localized")
