from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
menu_path = ROOT / 'app/src/main/res/menu/add_profile_menu.xml'
menu_text = menu_path.read_text()
ET.parse(menu_path)

# The app should rely on Android's single toolbar overflow control, not a second custom kebab menu.
assert 'action_misc' not in menu_text
assert 'android:id="@+id/action_clear_traffic_statistics"' in menu_text
assert 'android:id="@+id/action_remove_duplicate"' in menu_text
assert 'android:id="@+id/action_order_by_delay"' in menu_text
assert menu_text.count('android:id="@+id/action_update_subscription"') == 1

store = (ROOT / 'app/src/main/java/io/nekohasekai/sagernet/database/DataStore.kt').read_text()
startup = (ROOT / 'app/src/main/java/io/nekohasekai/sagernet/bg/AutoNodeStartup.kt').read_text()
fragment = (ROOT / 'app/src/main/java/io/nekohasekai/sagernet/ui/ConfigurationFragment.kt').read_text()
switch = (ROOT / 'app/src/main/java/io/nekohasekai/sagernet/ui/SwitchActivity.kt').read_text()
shortcut = (ROOT / 'app/src/main/java/io/nekohasekai/sagernet/QuickToggleShortcut.kt').read_text()

assert 'starjumpSelectedProxyManuallyChosen' in store
assert '{ selectedProxy > 0L }' in store
assert 'DataStore.selectedProxyManuallyChosen = true' in fragment
assert 'DataStore.selectedProxyManuallyChosen = true' in switch
assert 'DataStore.selectedProxyManuallyChosen = true' in shortcut
assert 'val hasValidManualSelection = DataStore.selectedProxyManuallyChosen' in startup
assert 'selected the fastest confirmed usable node' in startup
assert 'No usable node was confirmed; keeping the existing node selection' in startup
assert 'DataStore.selectedProxyManuallyChosen = false' in startup

# Existing groups migrate once to delay order; manual sorting changes persist afterward.
assert 'starjumpDelaySortDefaultsApplied' in store
assert 'if (!DataStore.delaySortDefaultsApplied)' in startup
assert 'existingGroup.order = io.nekohasekai.sagernet.GroupOrder.BY_DELAY' in startup
print('PASS: one native toolbar overflow replaces the duplicate kebab menu')
print('PASS: all existing overflow actions remain reachable')
print('PASS: manual node choices are persisted and respected')
print('PASS: without a valid manual choice, startup selects the fastest confirmed usable node only')
print('PASS: existing groups migrate to delay sorting once; later manual sort choices persist')


# The rightmost group-card entry keeps its original click target but displays a larger dark plus icon.
group_layout = (ROOT / 'app/src/main/res/layout/layout_group_item.xml').read_text()
ET.parse(ROOT / 'app/src/main/res/layout/layout_group_item.xml')
assert 'android:id="@+id/options"' in group_layout
options_block = group_layout.split('android:id="@+id/options"', 1)[1].split('/>', 1)[0]
assert 'android:layout_width="56dp"' in options_block
assert 'android:layout_height="56dp"' in options_block
assert 'android:padding="4dp"' in options_block
assert '@drawable/ic_baseline_add_40' in options_block
plus_icon = ROOT / 'app/src/main/res/drawable/ic_baseline_add_40.xml'
ET.parse(plus_icon)
assert 'android:width="40dp"' in plus_icon.read_text()
assert 'android:tint="#000000"' in plus_icon.read_text()
print('PASS: rightmost group-card entry uses a 40dp near-black plus icon in a 56dp touch target')
