#!/usr/bin/env bash
# Download and stage the sing-box GeoIP/GeoSite databases for the Android APK.
# Existing assets are left untouched unless BOTH databases have been fetched
# and validated successfully.
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
ASSET_DIR="${ROOT_DIR}/app/src/main/assets/sing-box"
mkdir -p "${ASSET_DIR}"

WORK_DIR="$(mktemp -d "${TMPDIR:-/tmp}/starjump-assets.XXXXXX")"
cleanup() {
  rm -rf "${WORK_DIR}"
}
trap cleanup EXIT

CURL_RETRY_ARGS=(
  --fail
  --location
  --silent
  --show-error
  --connect-timeout 20
  --max-time 240
  --retry 5
  --retry-delay 2
  --retry-max-time 240
)

fetch_latest_tag() {
  local repository="$1"
  local response_file="$2"
  local tag

  echo "Querying latest release: ${repository}" >&2
  curl "${CURL_RETRY_ARGS[@]}" \
    --header "Accept: application/vnd.github+json" \
    --header "X-GitHub-Api-Version: 2022-11-28" \
    --user-agent "StarJump-Android-Build" \
    --output "${response_file}" \
    "https://api.github.com/repos/${repository}/releases/latest"

  tag="$(python3 - "${response_file}" <<'PY'
import json
import re
import sys

with open(sys.argv[1], "r", encoding="utf-8") as source:
    payload = json.load(source)

tag = payload.get("tag_name")
if not isinstance(tag, str) or not re.fullmatch(r"[A-Za-z0-9._-]{1,100}", tag):
    raise SystemExit("GitHub release response has no valid tag_name")
print(tag)
PY
)"
  printf '%s' "${tag}"
}

download_database() {
  local repository="$1"
  local label="$2"
  local tag_file="${WORK_DIR}/${label}.release.json"
  local db_file="${WORK_DIR}/${label}.db"
  local xz_file="${WORK_DIR}/${label}.db.xz"
  local version_file="${WORK_DIR}/${label}.version.txt"
  local tag

  tag="$(fetch_latest_tag "${repository}" "${tag_file}")"
  echo "Selected ${label} release: ${tag}"

  curl "${CURL_RETRY_ARGS[@]}" \
    --output "${db_file}" \
    "https://github.com/${repository}/releases/download/${tag}/${label}.db"

  if [[ ! -s "${db_file}" ]]; then
    echo "ERROR: ${label}.db download is empty" >&2
    return 1
  fi

  if [[ "${label}" == "geoip" ]]; then
    # GeoIP is a MaxMind DB. GeoSite uses sing-box's own database format,
    # so do not incorrectly apply the MaxMind marker check to geosite.db.
    python3 - "${db_file}" <<'PY'
import pathlib
import sys

data = pathlib.Path(sys.argv[1]).read_bytes()
if len(data) < 128 or b"\xab\xcd\xefMaxMind.com" not in data:
    raise SystemExit("ERROR: geoip.db is not a valid MaxMind DB (metadata marker missing)")
PY
  fi

  xz -9 -c "${db_file}" > "${xz_file}"
  xz --test "${xz_file}"
  if [[ ! -s "${xz_file}" ]]; then
    echo "ERROR: compressed ${label}.db.xz is empty" >&2
    return 1
  fi

  printf '%s' "${tag}" > "${version_file}"
}

download_database "SagerNet/sing-geoip" "geoip"
download_database "SagerNet/sing-geosite" "geosite"

# Both assets are ready and validated. Stage destination files in the same
# filesystem, then rename into place so an interrupted download never leaves
# a truncated database in the APK assets directory.
for name in geoip geosite; do
  install -m 0644 "${WORK_DIR}/${name}.db.xz" "${ASSET_DIR}/${name}.db.xz.tmp"
  install -m 0644 "${WORK_DIR}/${name}.version.txt" "${ASSET_DIR}/${name}.version.txt.tmp"
done

for name in geoip geosite; do
  mv -f "${ASSET_DIR}/${name}.db.xz.tmp" "${ASSET_DIR}/${name}.db.xz"
  mv -f "${ASSET_DIR}/${name}.version.txt.tmp" "${ASSET_DIR}/${name}.version.txt"
done

echo "GeoIP and GeoSite assets downloaded, validated, compressed, and installed."
