from pathlib import Path

ROOT = Path(__file__).resolve().parent
HTTP = (ROOT / "libcore/http.go").read_text()
PROPS = (ROOT / "nb4a.properties").read_text()
assert "const defaultHTTPTimeout = 30 * time.Second" in HTTP
assert "client.h1h2Client.Timeout = defaultHTTPTimeout" in HTTP
assert HTTP.count("r.request.Clone(ctx)") >= 2
assert "request := r.request.Clone(context.Background())" not in HTTP
assert HTTP.count("Timeout: 10 * time.Second") >= 2
assert "if finalErr != nil" in HTTP
assert "return nil, ctx.Err()" in HTTP
assert "type cancelReadCloser struct" in HTTP
assert "result.Body = &cancelReadCloser{ReadCloser: result.Body, cancel: cancel}" in HTTP
assert "if !contextTransferred" in HTTP
assert "defer cancel()" not in HTTP[HTTP.index("func (r *httpRequest) doH3Direct()") : HTTP.index("type cancelReadCloser struct")]
assert "VERSION_NAME=6.00.47" in PROPS
assert "VERSION_CODE=70" in PROPS
print("PASS: standard HTTP requests have a 30-second total timeout")
print("PASS: ECH/HTTP3 requests inherit the cancellable 10-second context")
print("PASS: H3 timeout returns a non-nil context error when no branch reports first")
print("PASS: H3/ECH request context remains alive until response body is closed")
print("PASS: public version remains 6.00.47")
