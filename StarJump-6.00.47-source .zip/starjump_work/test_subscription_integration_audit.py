#!/usr/bin/env python3
"""Source-level regression checks for fail-closed subscription updates."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/RawUpdater.kt"
SIG = ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/SubscriptionSignature.kt"
BEAN = ROOT / "app/src/main/java/io/nekohasekai/sagernet/database/SubscriptionBean.java"

raw = RAW.read_text(encoding="utf-8")
sig = SIG.read_text(encoding="utf-8")
bean = BEAN.read_text(encoding="utf-8")
helper = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/ReferenceSubscription.kt").read_text()

# Signed bytes are verified before any parser invocation.
verify_at = raw.index("SubscriptionSignature.unwrap(")
parse_at = raw.index("parseRaw(parseText)")
assert verify_at < parse_at

# The candidate is fully parsed/validated before the DB transaction begins.
validation_at = raw.index("val invalidCount = candidate.count")
transaction_at = raw.index("SagerDatabase.instance.withTransaction")
assert parse_at < validation_at < transaction_at

# Profile rows and signed rollback state are committed in the same Room transaction.
transaction_end = raw.index("SagerDatabase.groupDao.updateGroup(proxyGroup)", transaction_at)
transaction_body = raw[transaction_at:transaction_end]
assert "subscription.lastSignedVersion = acceptedSignedVersion" in transaction_body
assert "subscription.lastSignedHash = acceptedSignedHash" in transaction_body
assert "SagerDatabase.groupDao.updateGroup(proxyGroup)" in raw[transaction_end:transaction_end + 100]

# A malformed Clash VMess/VLESS/Trojan node must abort, not silently disappear.
assert 'error("Invalid Clash proxy: missing server")' in raw
assert 'error("Invalid Clash proxy: missing or invalid port")' in raw
clash_start = raw.index('"vmess", "vless", "trojan" ->')
clash_end = raw.index('"anytls" ->', clash_start)
assert "?: continue" not in raw[clash_start:clash_end]

# A malformed WireGuard peer must abort the whole import/update.
assert '"Invalid WireGuard peer: missing endpoint"' in raw
assert '"Invalid WireGuard peer: invalid endpoint port"' in raw
assert '"Invalid WireGuard peer: missing public key"' in raw
wireguard_start = raw.index("fun parseWireGuard(")
wireguard_end = raw.index("fun parseJSON(", wireguard_start)
wireguard_parser = raw[wireguard_start:wireguard_end]
assert "continue" not in wireguard_parser
assert "Missing private key in 'Interface' selection" in wireguard_parser
assert "it in 1..65535" in wireguard_parser
assert "?.takeIf { it.isNotEmpty() }" in wireguard_parser
assert ".map { it.trim() }" in wireguard_parser

# Recovery/signing private material is not part of serialized subscription fields.
share = bean.split("public void serializeForShare", 1)[1].split("@Override", 1)[0]
assert "signingPublicKey" not in share
assert "recoveryPublicKey" not in share
assert "lastSignedVersion" not in share
assert "lastSignedHash" not in share

# Historical serialization versions remain explicitly supported.
assert "version >= 2 ? input.readString()" in bean
assert "version >= 3 ? input.readString()" in bean
assert "version >= 4 ? input.readString()" in bean

print("PASS: signature verification precedes parsing")
print("PASS: parsed result validation precedes database transaction")
print("PASS: node rows and signed rollback state are committed together")
print("PASS: malformed Clash VMess/VLESS/Trojan entries fail closed")
print("PASS: malformed WireGuard peers fail closed")
print("PASS: signed/recovery public-key pins and version state are excluded from share serialization")
print("PASS: subscription serialization migrations 1-4 remain represented")

print("PASS: WireGuard interface requires nonblank private key and address")
print("PASS: WireGuard peer key must be nonblank after trimming")
print("PASS: WireGuard endpoint port must be within 1..65535")

# Built-in StarJump group uses the exact Paste.gg URL and the same standard
# HTTP + parseRaw pipeline as clipboard-imported subscriptions.
assert 'val isReferenceGroup = proxyGroup.isStarJumpReservedGroup()' in raw
assert 'ReferenceSubscription.sourceUrlFor(proxyGroup)' in raw
assert 'https://paste.gg/p/xh/e08d0acaa7af4e7ca654cd938e0ba623/files/1940d97d791e432c960a5190d533abba/raw' in helper
assert 'EightDegreeSource.fetchAndDecrypt()' not in raw
assert 'tryH3Direct()' in raw
assert 'subscription.backupLink' in raw
assert 'parseRaw(parseText)' in raw

assert 'suspend fun ensureGroups(): List<ProxyGroup>' in helper
assert 'SagerDatabase.groupDao.subscriptions()' in helper
assert 'GroupManager.createGroup(' in helper
assert 'type = GroupType.SUBSCRIPTION' in helper
assert 'link = ""' in helper
assert 'starJumpBuiltIn = true' in helper
assert 'LEGACY_RAW_URL' in helper
assert 'group.name == GROUP_NAME ||' not in helper
assert 'DataStore.selectedGroup = result.first().id' in helper

print('PASS: StarJump slots use per-group source routing and the standard subscription parser')
print('PASS: ordinary user subscriptions retain their normal primary/backup behavior')
print('PASS: five persistent StarJump subscription groups are created idempotently')
print('PASS: built-in source shares the same HTTP and parseRaw pipeline as clipboard imports')

# Group/subscription metadata is staged and committed with profile rows. Room
# rolls back database state, while this explicit snapshot restores the mutable
# in-memory entities if any statement in the transaction fails.
remote_name_stage = raw.index("val acceptedRemoteName =")
transaction_start = raw.index("SagerDatabase.instance.withTransaction")
assert remote_name_stage < transaction_start
assert "subscription.subscriptionUserinfo = responseUserInfo" not in raw[:transaction_start]
assert "proxyGroup.name = it" not in raw[:transaction_start]
assert "val previousLastUpdated = subscription.lastUpdated" in raw
assert "val previousSignedVersion = subscription.lastSignedVersion" in raw
assert "val previousSignedHash = subscription.lastSignedHash" in raw
assert "val previousSigningPublicKey = subscription.signingPublicKey" in raw
rollback_start = raw.index("} catch (e: Throwable)", transaction_start)
rollback_end = raw.index("userInterface?.onUpdateSuccess", rollback_start)
rollback = raw[rollback_start:rollback_end]
for restore in (
    "proxyGroup.name = previousGroupName",
    "subscription.subscriptionUserinfo = previousUserInfo",
    "subscription.lastUpdated = previousLastUpdated",
    "subscription.lastSignedVersion = previousSignedVersion",
    "subscription.lastSignedHash = previousSignedHash",
    "subscription.signingPublicKey = previousSigningPublicKey",
):
    assert restore in rollback
print("PASS: failed Room transactions restore in-memory group/subscription metadata")

# A UI success callback runs only after the transaction commits. Its ordinary
# failure must not turn a successful data update into a reported update failure.
success_callback_at = raw.index("userInterface?.onUpdateSuccess(")
callback_end = raw.index("@Suppress(\"UNCHECKED_CAST\")", success_callback_at)
callback = raw[success_callback_at:callback_end]
assert "catch (e: kotlinx.coroutines.CancellationException)" in callback
assert "catch (e: Exception)" in callback
assert "Logs.w(e)" in callback
print("PASS: post-commit UI callback errors do not misreport committed subscription data as failed")
