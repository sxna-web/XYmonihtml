#!/usr/bin/env python3
"""Create a local, checksum-verified source snapshot. No upload is performed."""
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, os
from pathlib import Path
import zipfile

EXCLUDED_DIRS = {'.git','.gradle','.idea','.kotlin','build','captures','.cxx','.externalNativeBuild','node_modules','__pycache__'}
EXCLUDED_NAMES = {'local.properties','.DS_Store','Thumbs.db','.netrc','.npmrc','.pypirc','known_hosts'}
EXCLUDED_SUFFIXES = {'.jks','.keystore','.p12','.pfx','.pem','.key','.asc','.mobileprovision'}
EXCLUDED_PARTS = {'secret','secrets','credential','credentials','private-key','private_key','id_rsa','id_ed25519','id_ecdsa'}
EXCLUDED_PREFIXES = {'.env'}

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def should_skip(rel: Path, is_dir: bool) -> bool:
    if any(p in EXCLUDED_DIRS for p in rel.parts): return True
    if is_dir: return False
    low=rel.name.lower()
    if rel.name in EXCLUDED_NAMES or rel.suffix.lower() in EXCLUDED_SUFFIXES: return True
    if any(low.startswith(p) for p in EXCLUDED_PREFIXES): return True
    if any(p in low for p in EXCLUDED_PARTS): return True
    return False

def main() -> int:
    ap=argparse.ArgumentParser(description='Create a local source snapshot (no upload).')
    ap.add_argument('--source',required=True)
    ap.add_argument('--destination',required=True)
    a=ap.parse_args(); source=Path(a.source).expanduser().resolve(); dest=Path(a.destination).expanduser().resolve()
    if not source.is_dir(): ap.error(f'source directory does not exist: {source}')
    if dest==source or source in dest.parents: ap.error('destination must not be inside source')
    stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    out=dest/f'6.00-source-backup-{stamp}'; out.mkdir(parents=True,exist_ok=False)
    archive=out/'source-snapshot.zip'; included=[]; skipped=[]
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for root,dirs,files in os.walk(source):
            rp=Path(root); relroot=rp.relative_to(source)
            dirs[:]=sorted(d for d in dirs if not should_skip(relroot/d,True))
            for name in sorted(files):
                f=rp/name; rel=f.relative_to(source)
                if should_skip(rel,False): skipped.append(rel.as_posix()); continue
                if f.is_symlink() or not f.is_file(): skipped.append(rel.as_posix()+' [non-regular]'); continue
                z.write(f,rel.as_posix()); included.append(rel.as_posix())
    digest=sha256(archive)
    manifest={'project':'NekoBox Android 6.00','created_utc':stamp,'source_directory_name':source.name,'archive':archive.name,'archive_sha256':digest,'included_file_count':len(included),'skipped_file_count':len(skipped),'skipped_paths':skipped,'upload_performed':False}
    (out/'backup-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (out/'SHA256SUMS.txt').write_text(f'{digest}  {archive.name}\n',encoding='utf-8')
    if sha256(archive)!=digest: raise RuntimeError('SHA-256 verification failed')
    print(f'Backup created: {out}\nIncluded: {len(included)}; skipped: {len(skipped)}\nSHA-256: {digest}\nNo upload performed.')
    return 0
if __name__=='__main__': raise SystemExit(main())
