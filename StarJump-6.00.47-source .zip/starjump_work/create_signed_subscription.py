#!/usr/bin/env python3
"""Create an NBX signed-subscription envelope using a local OpenSSL private key.

The private key is read from disk and is never copied into the output envelope.
Requires the OpenSSL executable. The app receives only the matching public key.
"""
import argparse
import base64
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

FORMAT = "nbx-subscription-v1"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--private-key", required=True, help="Path to RSA PEM private key (keep secret)")
    parser.add_argument("--input", required=True, help="Raw subscription text file")
    parser.add_argument("--output", required=True, help="Output signed JSON envelope")
    parser.add_argument("--version", required=True, type=int, help="Monotonically increasing integer version")
    parser.add_argument("--expires-in", type=int, default=7 * 24 * 3600, help="Validity seconds (default: 7 days)")
    parser.add_argument("--next-public-key", help="Optional Base64 X.509 DER RSA public-key file to cross-sign for planned rotation")
    parser.add_argument("--recovery-private-key", help="Optional offline recovery RSA private key; signs emergency replacement authorization")
    args = parser.parse_args()

    openssl = shutil.which("openssl")
    if not openssl:
        parser.error("OpenSSL executable was not found")
    key = Path(args.private_key)
    source = Path(args.input)
    if not key.is_file() or not source.is_file():
        parser.error("Private key or input file does not exist")
    if args.recovery_private_key and args.next_public_key:
        parser.error("Use either planned rotation or emergency recovery, not both")
    if args.version < 1 or args.expires_in < 60 or args.expires_in > 90 * 24 * 3600:
        parser.error("Version must be positive; expiry must be 60 seconds to 90 days")

    payload = source.read_bytes()
    if not payload:
        parser.error("Subscription input is empty")
    issued_at = int(time.time())
    expires_at = issued_at + args.expires_in
    digest = hashlib.sha256(payload).hexdigest()
    message = f"{FORMAT}\n{args.version}\n{issued_at}\n{expires_at}\n{digest}".encode("utf-8")

    with tempfile.TemporaryDirectory(prefix="nbx-sign-") as temp:
        message_path = Path(temp) / "message.bin"
        signature_path = Path(temp) / "signature.bin"
        message_path.write_bytes(message)
        result = subprocess.run(
            [openssl, "dgst", "-sha256", "-sign", str(key), "-out", str(signature_path), str(message_path)],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            print("OpenSSL signing failed:", result.stderr.strip(), file=sys.stderr)
            return 2
        signature = signature_path.read_bytes()
        rotation = None
        if args.next_public_key:
            next_key_file = Path(args.next_public_key)
            if not next_key_file.is_file():
                parser.error("Next public-key file does not exist")
            next_key_b64 = next_key_file.read_text(encoding="ascii").strip()
            try:
                next_key_bytes = base64.b64decode(next_key_b64, validate=True)
            except Exception:
                parser.error("Next public key must be Base64-encoded X.509 DER")
            if not next_key_bytes:
                parser.error("Next public key is empty")
            next_fingerprint = hashlib.sha256(next_key_bytes).hexdigest()
            rotation_message = f"nbx-key-rotation-v1\n{next_fingerprint}".encode("utf-8")
            rotation_path = Path(temp) / "rotation-message.bin"
            rotation_sig_path = Path(temp) / "rotation-signature.bin"
            next_der_path = Path(temp) / "next-public-key.der"
            next_der_path.write_bytes(next_key_bytes)
            key_check = subprocess.run(
                [openssl, "pkey", "-pubin", "-inform", "DER", "-in", str(next_der_path), "-text", "-noout"],
                capture_output=True, text=True
            )
            match = re.search(r"Public-Key:\s*\((\d+) bit\)", key_check.stdout)
            if key_check.returncode != 0 or not match or int(match.group(1)) < 2048:
                parser.error("Next public key must be a valid RSA key of at least 2048 bits")
            try:
                rotation_path.write_bytes(rotation_message)
                rotation_result = subprocess.run(
                    [openssl, "dgst", "-sha256", "-sign", str(key), "-out", str(rotation_sig_path), str(rotation_path)],
                    capture_output=True, text=True
                )
                if rotation_result.returncode != 0:
                    print("OpenSSL key-rotation signing failed:", rotation_result.stderr.strip(), file=sys.stderr)
                    return 2
                rotation = {
                    "public_key": base64.b64encode(next_key_bytes).decode("ascii"),
                    "signature": base64.b64encode(rotation_sig_path.read_bytes()).decode("ascii"),
                }
            finally:
                rotation_path.unlink(missing_ok=True)
                rotation_sig_path.unlink(missing_ok=True)

        recovery = None
        if args.recovery_private_key:
            recovery_key = Path(args.recovery_private_key)
            if not recovery_key.is_file():
                parser.error("Offline recovery private-key file does not exist")
            recovery_key_check = subprocess.run(
                [openssl, "pkey", "-in", str(recovery_key), "-text", "-noout"],
                capture_output=True, text=True
            )
            recovery_match = re.search(r"Private-Key:\s*\((\d+) bit", recovery_key_check.stdout)
            if recovery_key_check.returncode != 0 or not recovery_match or int(recovery_match.group(1)) < 2048:
                parser.error("Offline recovery private key must be RSA and at least 2048 bits")
            replacement_public_path = Path(temp) / "replacement-public.der"
            recovery_message_path = Path(temp) / "recovery-message.bin"
            recovery_signature_path = Path(temp) / "recovery-signature.bin"
            exported = subprocess.run(
                [openssl, "pkey", "-in", str(key), "-pubout", "-outform", "DER", "-out", str(replacement_public_path)],
                capture_output=True, text=True
            )
            if exported.returncode != 0:
                print("Could not derive replacement public key:", exported.stderr.strip(), file=sys.stderr)
                return 2
            replacement_der = replacement_public_path.read_bytes()
            replacement_check = subprocess.run(
                [openssl, "pkey", "-pubin", "-inform", "DER", "-in", str(replacement_public_path), "-text", "-noout"],
                capture_output=True, text=True
            )
            match = re.search(r"Public-Key:\s*\((\d+) bit\)", replacement_check.stdout)
            if replacement_check.returncode != 0 or not match or int(match.group(1)) < 2048:
                parser.error("Replacement signing key must be RSA and at least 2048 bits")
            fingerprint = hashlib.sha256(replacement_der).hexdigest()
            recovery_message = (
                f"nbx-key-recovery-v1\n{fingerprint}\n{args.version}\n"
                f"{issued_at}\n{expires_at}\n{digest}"
            ).encode("utf-8")
            recovery_message_path.write_bytes(recovery_message)
            recovery_result = subprocess.run(
                [openssl, "dgst", "-sha256", "-sign", str(recovery_key), "-out", str(recovery_signature_path), str(recovery_message_path)],
                capture_output=True, text=True
            )
            if recovery_result.returncode != 0:
                print("Offline recovery signing failed:", recovery_result.stderr.strip(), file=sys.stderr)
                return 2
            recovery = {
                "new_public_key": base64.b64encode(replacement_der).decode("ascii"),
                "signature": base64.b64encode(recovery_signature_path.read_bytes()).decode("ascii"),
            }

    envelope = {
        "format": FORMAT,
        "version": args.version,
        "issued_at": issued_at,
        "expires_at": expires_at,
        "payload": base64.b64encode(payload).decode("ascii"),
        "signature": base64.b64encode(signature).decode("ascii"),
    }
    if rotation is not None:
        envelope["key_rotation"] = rotation
    if recovery is not None:
        envelope["key_recovery"] = recovery
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(envelope, ensure_ascii=False, separators=(",", ":")) + "\n", encoding="utf-8")
    print(f"Signed envelope created: {output}")
    print(f"Version: {args.version}; payload SHA-256: {digest}")
    print("Signing private key was used locally and is not included in the envelope.")
    if recovery is not None:
        print("Offline recovery authorization was added; keep the recovery private key offline.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
