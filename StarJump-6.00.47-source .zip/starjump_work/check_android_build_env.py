#!/usr/bin/env python3
"""Read-only preflight for the LanBridge/NekoBox Android source build."""
from __future__ import annotations
import json, os, re, shutil, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def read(path: str) -> str:
    p = ROOT / path
    return p.read_text(encoding='utf-8', errors='replace') if p.exists() else ''

def command(args: list[str]) -> tuple[int, str]:
    exe = shutil.which(args[0])
    if not exe:
        return 127, 'not installed'
    try:
        p = subprocess.run([exe, *args[1:]], capture_output=True, text=True, timeout=12)
        return p.returncode, (p.stdout + p.stderr).strip().splitlines()[0:5].__str__()
    except Exception as e:
        return 1, str(e)

def prop(text: str, key: str):
    m = re.search(rf'^\s*{re.escape(key)}\s*=\s*(.+?)\s*$', text, re.M)
    return m.group(1) if m else None

def main() -> int:
    helpers = read('buildSrc/src/main/kotlin/Helpers.kt')
    buildsrc = read('buildSrc/build.gradle.kts')
    wrapper = read('gradle/wrapper/gradle-wrapper.properties')
    appbuild = read('app/build.gradle.kts')
    go_files = [p for p in ROOT.rglob('*') if p.is_file() and p.suffix in {'.go', '.mod'}]
    result = {
        'project': 'LanBridge (provisional brand) / NekoBox fork',
        'read_only': True,
        'android': {
            'compile_sdk': int(re.search(r'compileSdk\s*=\s*(\d+)', helpers).group(1)) if re.search(r'compileSdk\s*=\s*(\d+)', helpers) else None,
            'target_sdk': int(re.search(r'targetSdk\s*=\s*(\d+)', helpers).group(1)) if re.search(r'targetSdk\s*=\s*(\d+)', helpers) else None,
            'min_sdk': int(re.search(r'minSdk\s*=\s*(\d+)', helpers).group(1)) if re.search(r'minSdk\s*=\s*(\d+)', helpers) else None,
            'build_tools': prop(helpers, 'buildToolsVersion'),
            'abis_declared': sorted(set(re.findall(r'include\("([^"]+)"\)', helpers))),
            'sdk_path': os.environ.get('ANDROID_SDK_ROOT') or os.environ.get('ANDROID_HOME'),
        },
        'toolchain': {
            'agp': re.search(r'com\.android\.tools\.build:gradle:([^"\']+)', buildsrc).group(1) if re.search(r'com\.android\.tools\.build:gradle:([^"\']+)', buildsrc) else None,
            'kotlin': re.search(r'kotlin-gradle-plugin:([^"\']+)', buildsrc).group(1) if re.search(r'kotlin-gradle-plugin:([^"\']+)', buildsrc) else None,
            'gradle_distribution': re.search(r'distributionUrl=.*gradle-([^/]+)-', wrapper).group(1) if re.search(r'distributionUrl=.*gradle-([^/]+)-', wrapper) else None,
            'java': command(['java', '-version'])[1],
            'go': command(['go', 'version'])[1],
            'python': sys.version.split()[0],
            'go_source_files_found': len(go_files),
        },
        'checks': [],
    }
    a = result['android']; t = result['toolchain']
    result['checks'].append({'name':'Android SDK path','status':'PASS' if a['sdk_path'] and Path(a['sdk_path']).exists() else 'BLOCKED','detail':a['sdk_path'] or 'ANDROID_SDK_ROOT/ANDROID_HOME not set'})
    result['checks'].append({'name':'Gradle wrapper','status':'PASS' if (ROOT/'gradlew').exists() and (ROOT/'gradle/wrapper/gradle-wrapper.jar').exists() else 'BLOCKED','detail':'wrapper files present' if (ROOT/'gradlew').exists() else 'wrapper missing'})
    result['checks'].append({'name':'Android 16 target','status':'PASS' if a['target_sdk'] and a['target_sdk'] >= 36 else 'NEEDS_REVIEW','detail':f"targetSdk={a['target_sdk']}; API 36 target is a project goal, not yet applied"})
    result['checks'].append({'name':'Go toolchain','status':'NEEDS_REVIEW' if 'go1.23' in str(t['go']) else 'CHECK_MANUALLY','detail':t['go']})
    result['checks'].append({'name':'ABI declarations','status':'PASS' if 'arm64-v8a' in a['abis_declared'] and 'armeabi-v7a' in a['abis_declared'] else 'NEEDS_REVIEW','detail':', '.join(a['abis_declared']) or 'none found'})
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
