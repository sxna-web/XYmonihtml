#!/usr/bin/env python3
"""Regression checks for subscription update lock/progress cleanup."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
updater = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/GroupUpdater.kt").read_text()
raw = (ROOT / "app/src/main/java/io/nekohasekai/sagernet/group/RawUpdater.kt").read_text()

start = updater.index("private suspend fun executeUpdateClaimed(")
end = updater.index("suspend fun finishUpdate(", start)
body = updater[start:end]

# The initial reload, missing-subscription return, user confirmation, and network
# update all execute under a single try/finally after the group lock is claimed.
assert body.index("try {") < body.index("GroupManager.postReload(proxyGroup.id)")
assert body.index("try {") < body.index("userInterface.confirm(")
assert "finally {" in body
assert "finishUpdate(proxyGroup)" in body
assert body.index("finally {") < body.index("finishUpdate(proxyGroup)")

# Cleanup has one owner; RawUpdater must not post completion twice or unlock early.
assert "finishUpdate(proxyGroup)" not in raw
assert "updating.remove(proxyGroup.id)" in updater
assert "progress.remove(proxyGroup.id)" in updater

# Cancellation propagates only after the finally cleanup has been guaranteed.
assert "if (e is CancellationException) throw e" in body
print("PASS: every claimed subscription update path releases updating/progress state")
print("PASS: confirmation and initial reload failures cannot leak the update lock")
print("PASS: RawUpdater no longer performs duplicate/early completion cleanup")
print("PASS: coroutine cancellation propagates after guaranteed cleanup")

# UI refresh notification is cleanup work too: it must survive cancellation,
# and listener failures must not resurrect the update lock or mask the result.
finish_start = updater.index("suspend fun finishUpdate(")
finish_end = updater.index("\n        }", finish_start) + len("\n        }")
finish = updater[finish_start:finish_end]
assert "updating.remove(proxyGroup.id)" in finish
assert "progress.remove(proxyGroup.id)" in finish
assert "withContext(NonCancellable)" in finish
assert "GroupManager.postUpdate(proxyGroup)" in finish
assert "catch (e: Exception)" in finish
assert finish.index("updating.remove") < finish.index("GroupManager.postUpdate")
assert finish.index("progress.remove") < finish.index("GroupManager.postUpdate")
print("PASS: completion UI notification survives parent cancellation")
print("PASS: listener exceptions cannot retain update lock/progress state")
