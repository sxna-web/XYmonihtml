#!/usr/bin/env python3
"""Encrypt a source backup with GnuPG AES-256; passphrase is entered by GPG."""
from __future__ import annotations
import argparse
import shutil
import subprocess
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Encrypt a ZIP backup using GnuPG symmetric AES-256.")
    parser.add_argument("archive", help="source-snapshot.zip")
    parser.add_argument("--output", help="output file; defaults to <archive>.gpg")
    parser.add_argument("--remove-plaintext", action="store_true", help="remove plaintext ZIP only after successful encryption")
    args = parser.parse_args()

    gpg = shutil.which("gpg")
    if not gpg:
        raise SystemExit("GnuPG (gpg) is not installed. Install it before encrypting backups.")
    source = Path(args.archive).expanduser().resolve()
    if not source.is_file():
        parser.error("archive does not exist")
    output = Path(args.output).expanduser().resolve() if args.output else Path(str(source) + ".gpg")
    if output.exists():
        parser.error(f"output already exists; choose another path: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)

    # GPG prompts for the passphrase interactively. It is never put in argv,
    # environment variables, source files, or logs.
    result = subprocess.run([
        gpg, "--symmetric", "--cipher-algo", "AES256",
        "--output", str(output), str(source)
    ], check=False)
    if result.returncode != 0 or not output.is_file() or output.stat().st_size == 0:
        output.unlink(missing_ok=True)
        raise SystemExit("Encryption failed; plaintext ZIP was retained.")

    if args.remove_plaintext:
        source.unlink()
    print(f"Encrypted backup: {output}")
    print("Cipher: OpenPGP symmetric AES-256")
    print(f"Plaintext ZIP removed: {'yes' if args.remove_plaintext else 'no'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
